package az.balaken.elan;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.view.ViewGroup;
import android.widget.Toast;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.util.Locale;

/** BalakənElan v103: packaged site; no reliance on localhost or a running PC. */
public class MainActivity extends Activity {
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String LOCAL_ROOT = "https://appassets.androidplatform.net/";
    private static final int FILE_PICKER_REQUEST = 750;
    private WebView browser;
    private ValueCallback<Uri[]> filePickerCallback;
    private JSONObject pendingOAuth;
    private boolean siteReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        browser = new WebView(this);
        browser.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setContentView(browser);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        browser.addJavascriptInterface(new AndroidBridge(), "BalakenAndroid");
        browser.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost())) {
                    return getLocalAsset(uri.getPath());
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost())) return false;
                String scheme = uri.getScheme();
                if ("tel".equals(scheme) || "mailto".equals(scheme)) { openExternal(uri); return true; }
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    // Supabase API calls and image fetches are network subresources;
                    // top-level navigation is deliberately external.
                    if (request.isForMainFrame()) { openExternal(uri); return true; }
                    return false;
                }
                if ("balakenelan".equals(scheme)) {handleCallback(uri);return true;}
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith(LOCAL_ROOT)) {siteReady = true; deliverOAuth();}
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePickerCallback != null) filePickerCallback.onReceiveValue(null);
                filePickerCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(intent, "Şəkilləri seç"), FILE_PICKER_REQUEST);
                    return true;
                } catch (Exception ex) {
                    filePickerCallback = null;
                    return false;
                }
            }
        });
        if (state != null) {
            browser.restoreState(state);
        } else {
            browser.loadUrl(LOCAL_ROOT + "index.html");
        }
        if (getIntent() != null) handleCallback(getIntent().getData());
    }

    private WebResourceResponse getLocalAsset(String urlPath) {
        String clean = urlPath == null ? "" : Uri.decode(urlPath);
        if (clean.startsWith("/")) clean = clean.substring(1);
        if (clean.isEmpty()) clean = "index.html";
        if (clean.contains("..") || clean.contains("\\") || clean.indexOf('\0') >= 0) {
            return new WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", null,
                    new java.io.ByteArrayInputStream(new byte[0]));
        }
        try {
            InputStream stream = getAssets().open("www/" + clean);
            String mime = URLConnection.guessContentTypeFromName(clean);
            if (clean.endsWith(".js")) mime = "application/javascript";
            if (clean.endsWith(".webp")) mime = "image/webp";
            if (clean.endsWith(".css")) mime = "text/css";
            if (clean.endsWith(".webmanifest")) mime = "application/manifest+json";
            if (mime == null) mime = "application/octet-stream";
            return new WebResourceResponse(mime, "utf-8", stream);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null,
                    new java.io.ByteArrayInputStream(new byte[0]));
        }
    }
    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)); }
        catch (Exception e) { Toast.makeText(this, "Brauzer tapılmadı", Toast.LENGTH_SHORT).show(); }
    }
    private final class AndroidBridge {
        @JavascriptInterface public void openOAuth(String url) {
            try {
                Uri uri = Uri.parse(url);
                // Constrain JS bridge: OAuth endpoints from our own Supabase project only.
                if (!"https".equals(uri.getScheme())
                    || !"dcqlkzziubfyssctmvrk.supabase.co".equals(uri.getHost())
                    || !"/auth/v1/authorize".equals(uri.getPath())) return;
                runOnUiThread(() -> openExternal(uri));
            } catch (Exception ignored) { }
        }
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleCallback(intent == null ? null : intent.getData());
    }
    private void handleCallback(Uri uri) {
        if (uri == null || !"balakenelan".equals(uri.getScheme()) || !"auth-callback".equals(uri.getHost())) return;
        try {
            JSONObject data = new JSONObject();
            if (uri.getFragment() != null) {
                Uri hash = Uri.parse("https://callback.invalid/?" + uri.getFragment());
                putIfPresent(data, "access_token", hash.getQueryParameter("access_token"));
                putIfPresent(data, "refresh_token", hash.getQueryParameter("refresh_token"));
                putIfPresent(data, "error", hash.getQueryParameter("error_description"));
            }
            putIfPresent(data, "code", uri.getQueryParameter("code"));
            putIfPresent(data, "error", uri.getQueryParameter("error_description"));
            putIfPresent(data, "error", uri.getQueryParameter("error"));
            pendingOAuth = data;
            deliverOAuth();
        } catch (Exception e) { Log.e("BalakenElan", "OAuth callback parse failed", e); }
    }
    private void putIfPresent(JSONObject obj, String key, String val) throws Exception {
        if (val != null && !val.isEmpty() && !obj.has(key)) obj.put(key, val);
    }
    private void deliverOAuth() {
        if (!siteReady || pendingOAuth == null || browser == null) return;
        JSONObject payload = pendingOAuth;
        pendingOAuth = null;
        // Escaped JSON argument prevents arbitrary JavaScript injection.
        String js = "if (typeof window.BALAKEN_NATIVE_AUTH_CALLBACK === 'function') "
                + "window.BALAKEN_NATIVE_AUTH_CALLBACK(" + payload.toString() + ");";
        browser.post(() -> browser.evaluateJavascript(js, null));
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != FILE_PICKER_REQUEST || filePickerCallback == null) return;
        Uri[] selected = null;
        if (result == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                selected = new Uri[n];
                for (int i = 0; i < n; i++) selected[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                selected = new Uri[]{data.getData()};
            }
        }
        filePickerCallback.onReceiveValue(selected);
        filePickerCallback = null;
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        browser.saveState(out);super.onSaveInstanceState(out);
    }
    @Override public void onBackPressed() {
        if (browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (browser != null) { browser.destroy(); browser = null; }
        super.onDestroy();
    }
}
