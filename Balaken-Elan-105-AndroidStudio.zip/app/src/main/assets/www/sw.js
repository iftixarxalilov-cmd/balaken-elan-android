const VERSION='balaken-elan-android-v103';
const CORE=['./','./index.html','./css/style.css','./js/config.js','./js/app.js','./js/i18n.js','./js/pagination.js','./js/inline-locations.js','./seller-ads.html','./js/seller-ads.js'];
self.addEventListener('install', e=>{e.waitUntil(caches.open(VERSION).then(c=>c.addAll(CORE)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==VERSION).map(k=>caches.delete(k)))));self.clients.claim()});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==location.origin)return;
e.respondWith(fetch(e.request).then(r=>{if(r.ok){const c=r.clone();caches.open(VERSION).then(cache=>cache.put(e.request,c))}return r}).catch(()=>caches.match(e.request))) });
