// Supabase layihə məlumatlarını buraya yaz.
// E-poçt təsdiqi üçün yönləndirmə Supabase Authentication > URL Configuration > Site URL ünvanından alınır.
// Lokal file:// ünvanını və Live Server localhost ünvanını qeydiyyata birbaşa yönləndirmə kimi ötürmə.
 // Bu faylda yalnız Project URL və publishable/anon key ola bilər.
 // service_role / secret key-i heç vaxt brauzer koduna yerləşdirmə.
window.BALAKEN_CONFIG = {
  supabaseUrl:  "https://dcqlkzziubfyssctmvrk.supabase.co",
  supabaseAnonKey:  "sb_publishable_-huJTeoJCb3BhluCf-6lRg_XTIZfrGm"
};

// Mənbə: Azərbaycan Dövlət Statistika Komitəsi, İnzibati ərazi bölgüsü təsnifatı (2024)
// https://www.azstat.gov.az/tesnifat/cedeveller/arazi.jsp?parm=arazi
// 1 şəhər, 1 qəsəbə, 57 kənd. Adlar verilənlər bazasında saxlanılan mətnlə müqayisə olunur.
window.BALAKEN_LOCATIONS = [
  {group:"Şəhər", name:"Balakən şəhəri"},
  {group:"Qəsəbə", name:"Qabaqçöl"},
  {group:"Kəndlər · Gərəkli ərazi dairəsi",name:"Gərəkli"},
  {group:"Kəndlər · Gərəkli ərazi dairəsi",name:"Çorçorbinə"},
  {group:"Kəndlər · Gərəkli ərazi dairəsi",name:"Mazımçay"},
  {group:"Kəndlər · Gərəkli ərazi dairəsi",name:"Poştbinə"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Hənifə"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Böyüktala"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Cincartala"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Əyritala"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Göyəmtala"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Gülüzanbinə"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Məlikzadə"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Murğuztala"},
  {group:"Kəndlər · Hənifə ərazi dairəsi",name:"Roçəhməd"},
  {group:"Kəndlər · Xalatala ərazi dairəsi",name:"Xalatala"},
  {group:"Kəndlər · Xalatala ərazi dairəsi",name:"Göyrüclük"},
  {group:"Kəndlər · İtitala ərazi dairəsi",name:"İtitala"},
  {group:"Kəndlər · Katex ərazi dairəsi",name:"Katex"},
  {group:"Kəndlər · Katex ərazi dairəsi",name:"Beretbinə"},
  {group:"Kəndlər · Kortala ərazi dairəsi",name:"Kortala"},
  {group:"Kəndlər · Kortala ərazi dairəsi",name:"Beçeqarbinə"},
  {group:"Kəndlər · Kortala ərazi dairəsi",name:"Qarahacılı"},
  {group:"Kəndlər · Qaysa ərazi dairəsi",name:"Qaysa"},
  {group:"Kəndlər · Qaysa ərazi dairəsi",name:"Abjit"},
  {group:"Kəndlər · Qazma ərazi dairəsi",name:"Qazma"},
  {group:"Kəndlər · Qazma ərazi dairəsi",name:"Bedağar"},
  {group:"Kəndlər · Qazma ərazi dairəsi",name:"Cillik"},
  {group:"Kəndlər · Qazma ərazi dairəsi",name:"Darvazbinə"},
  {group:"Kəndlər · Qazma ərazi dairəsi",name:"Öküzovtala"},
  {group:"Kəndlər · Qazma ərazi dairəsi",name:"Şambulbinə"},
  {group:"Kəndlər · Qullar ərazi dairəsi",name:"Qullar"},
  {group:"Kəndlər · Qullar ərazi dairəsi",name:"Acılıqbinə"},
  {group:"Kəndlər · Mahamalar ərazi dairəsi",name:"Mahamalar"},
  {group:"Kəndlər · Mahamalar ərazi dairəsi",name:"Qaracabinə"},
  {group:"Kəndlər · Mahamalar ərazi dairəsi",name:"Qasbinə"},
  {group:"Kəndlər · Mahamalar ərazi dairəsi",name:"Solban"},
  {group:"Kəndlər · Meşəşambul ərazi dairəsi",name:"Meşəşambul"},
  {group:"Kəndlər · Meşəşambul ərazi dairəsi",name:"Qazbölük"},
  {group:"Kəndlər · Püştətala ərazi dairəsi",name:"Püştətala"},
  {group:"Kəndlər · Püştətala ərazi dairəsi",name:"Qadaşbinə"},
  {group:"Kəndlər · Püştətala ərazi dairəsi",name:"Qamıştala"},
  {group:"Kəndlər · Püştətala ərazi dairəsi",name:"Qaravəli"},
  {group:"Kəndlər · Püştətala ərazi dairəsi",name:"Mollaçıbinə"},
  {group:"Kəndlər · Püştətala ərazi dairəsi",name:"Pirqax"},
  {group:"Kəndlər · Sarıbulaq ərazi dairəsi",name:"Sarıbulaq"},
  {group:"Kəndlər · Sarıbulaq ərazi dairəsi",name:"Ağkilsə"},
  {group:"Kəndlər · Sarıbulaq ərazi dairəsi",name:"Cederovtala"},
  {group:"Kəndlər · Sarıbulaq ərazi dairəsi",name:"Kilsəbuqov"},
  {group:"Kəndlər · Şambul ərazi dairəsi",name:"Şambul"},
  {group:"Kəndlər · Şambul ərazi dairəsi",name:"İsaxlıgirmə"},
  {group:"Kəndlər · Şərif ərazi dairəsi",name:"Şərif"},
  {group:"Kəndlər · Talalar ərazi dairəsi",name:"Talalar"},
  {group:"Kəndlər · Talalar ərazi dairəsi",name:"Bayrambinə"},
  {group:"Kəndlər · Talalar ərazi dairəsi",name:"Hetovlar"},
  {group:"Kəndlər · Tülü ərazi dairəsi",name:"Tülü"},
  {group:"Kəndlər · Tülü ərazi dairəsi",name:"Mazımqarışan"},
  {group:"Kəndlər · Tülü ərazi dairəsi",name:"Mazımüstü"},
  {group:"Kəndlər · Yeni Şərif ərazi dairəsi",name:"Yeni Şərif"},
];
window.BALAKEN_CATEGORIES = [
  {name:"Elektrik və ev əşyaları",emoji:"🧊"},
  {name:"Telefon və elektronika",emoji:"📱"},
  {name:"Mebel",emoji:"🛋️"},
  {name:"Avtomobil",emoji:"🚗"},
  {name:"Ev və torpaq",emoji:"🏡"},
  {name:"Heyvanlar",emoji:"🐄"},
  {name:"Geyim və ayaqqabı",emoji:"👕"},
  {name:"İş elanları",emoji:"💼"},
  {name:"Xidmətlər",emoji:"🛠️"},
  {name:"Kirayə",emoji:"🔑"},
  {name:"Digər",emoji:"📦"}
];

// V54: Kullanıcı isteğine göre Qabaqçöl seçiminin altında 6 kənd ərazi dairəsi
// alt səviyyədə açılır. Bu saytın naviqasiya qrupudur; rəsmi tabelik iddiası deyil.
// Ərazi dairələrinə bağlı kəndlər window.BALAKEN_LOCATIONS-dan götürülür.
window.BALAKEN_QABAQCOL_SUBAREAS = ["Xalatala","Meşəşambul","Şərif","Yeni Şərif","Qaysa","Şambul"];
window.BALAKEN_LOCATION_TREE = (() => {
  const tree = [{label:"Balakən",type:"Şəhər",places:["Balakən şəhəri"]}];
  const groups = new Map();
  (window.BALAKEN_LOCATIONS||[]).filter(x=>x.group.startsWith("Kəndlər · ")).forEach(x=>{
    const area=x.group.replace(/^Kəndlər · /,"").replace(/ ərazi dairəsi$/,"");
    if(!groups.has(area))groups.set(area, []);
    groups.get(area).push(x.name);
  });
  // Qabaqçöl seçəndə altından bu 6 ərazi dairəsi açılır.
  const subareas = window.BALAKEN_QABAQCOL_SUBAREAS.map(label=>({label,type:"Kənd",places:groups.get(label)||[]}));
  tree.push({label:"Qabaqçöl",type:"Qəsəbə qrupu",places:["Qabaqçöl"],subareas});
  [...groups.entries()].sort((a,b)=>a[0].localeCompare(b[0],"az"))
    .filter(([label])=>!window.BALAKEN_QABAQCOL_SUBAREAS.includes(label))
    .forEach(([label,places])=>tree.push({label,type:"Kənd",places}));
  return tree;
})();
