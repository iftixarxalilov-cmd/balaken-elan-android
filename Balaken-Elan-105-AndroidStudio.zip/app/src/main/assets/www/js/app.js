(() => {
const $ = id => document.getElementById(id);
const cfg = window.BALAKEN_CONFIG || {};
const configured = cfg.supabaseUrl && cfg.supabaseAnonKey &&
  !cfg.supabaseUrl.includes("BURAYA") && !cfg.supabaseAnonKey.includes("BURAYA");
let db = null, session = null, currentUser = null, ads = [], chosenCategory = "";
let galleryImages = [], galleryIndex = 0;
let toastTimer;
let passwordRecoveryActive=false;
if (configured && window.supabase?.createClient) db = window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey);

function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),4200)}
function showOAuthCallbackError(){
 const params=new URLSearchParams(window.location.search);
 const fragment=new URLSearchParams(window.location.hash.replace(/^#/,""));
 ["error","error_code","error_description"].forEach(key=>{if(!params.has(key)&&fragment.has(key))params.set(key,fragment.get(key))});
 const code=params.get("error_code"),description=params.get("error_description"),error=params.get("error");
 if(!error&&!code&&!description)return;
 const readable=description?description.replace(/\+/g," "):"Google ilə giriş tamamlanmadı.";
 console.error("OAuth callback xətası:",{error,code,description});
 toast("Google girişi alınmadı: "+readable);
 // Remove OAuth error parameters from the address bar without reloading the page.
 window.history.replaceState({},document.title,window.location.origin+window.location.pathname);
}
function showModal(id){$(id).hidden=false}
function closeModal(id){$(id).hidden=true}
let accountView=false, adminLandingUser=null;
function setAccountView(show){
 accountView=Boolean(show);
 ["homeSearchPanel","homeCategoriesPanel","homeAdsPanel"].forEach(id=>{const el=$(id);if(el)el.hidden=accountView});
 const staff=$("adminPanel").dataset.staff==="yes";
 $("accountPanel").hidden=!accountView || !currentUser || staff;
 $("myAdsPanel").hidden=!accountView || !currentUser || staff;
 $("newAdOpen").hidden=Boolean(currentUser&&staff);
 $("adminPanel").hidden=!accountView || !currentUser || $("adminPanel").dataset.staff!=="yes";
 const button=$("authOpen");
 if(button && currentUser)button.textContent=accountView?"Ana səhifə":(staff?"Admin paneli":"Hesabım");
}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>{closeModal(b.dataset.close);if(b.dataset.close==="adModal")resetAdForm()}));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.hidden=true}));
const adDetailClose=$("adDetailClose");if(adDetailClose)adDetailClose.addEventListener("click",()=>closeModal("adDetailModal"));
// V55 — Alt kəndlər yalnız konkret ərazi dairəsi seçiləndə göstərilir.
// Qabaqçöl ətrafı sayt üçün naviqasiya qrupudur, rəsmi inzibati tabelik deyil.
const locationTree=window.BALAKEN_LOCATION_TREE||[];
const qabaqcolSubareas=window.BALAKEN_QABAQCOL_SUBAREAS||[];
const qabaqcolRegion=locationTree.find(r=>r.label==="Qabaqçöl");
function findRegion(name){return locationTree.find(r=>r.label===name)}
function findSubarea(name){return qabaqcolRegion?.subareas?.find(r=>r.label===name)}
function regionLabel(r){
 if(r.type==="Şəhər")return "Balakən şəhəri";
 if(r.type==="Qəsəbə qrupu")return "Qabaqçöl · qəsəbə və ətraf ərazi dairələri";
 return r.label+" kənd ərazi dairəsi";
}
function displayPlaceName(region,place){
 return region.type==="Şəhər"?"Balakən şəhəri":region.type==="Qəsəbə qrupu"?"Qabaqçöl qəsəbəsi":place+" kəndi";
}
function fillLocationParents(select,firstLabel){
 select.replaceChildren(new Option(firstLabel,""));
 // Ana siyahıya yalnız ərazi dairələrinin adı yazılır, alt kəndlər yox.
 locationTree.forEach(region=>select.append(new Option(regionLabel(region),region.label)));
}
function selectedAreaGroup(kind){
 return $(kind==="filter"?"locationFilter":"adLocation").value;
}
function locationAreaNote(kind){
 const isFilter=kind==="filter";
 const parent=selectedAreaGroup(kind);
 const child=$(isFilter?"locationChildFilter":"adLocationChild").value;
 const village=$(isFilter?"locationVillageFilter":"adLocationVillage").value;
 const target=$(isFilter?"filterLocationNote":"adLocationHelp");
 const region=findRegion(parent);
 if(!region){target.textContent=isFilter?"Əvvəl ərazi seç. Alt seçimlər elə bunun altında görünəcək.":"Əvvəl ərazi seç. Növbəti seçimlər burada açılacaq.";return}
 if(parent==="Qabaqçöl"){
  if(child==="Qabaqçöl"){target.textContent="Seçildi: Qabaqçöl qəsəbəsi.";return}
  if(child){target.textContent=village?"Seçildi: Qabaqçöl → "+child+" ərazi dairəsi → "+village+" kəndi.":"Qabaqçöl seçildi. İndi istəsən düz aşağıdan "+child+" ərazi dairəsinə aid kəndi də seçə bilərsən.";return}
  target.textContent="Qabaqçöl seçildi. Düz aşağıdan Xalatala, Meşəşambul, Şərif, Yeni Şərif, Qaysa və ya Şambul ərazi dairəsini seç.";return;
 }
 if(child)target.textContent="Seçildi: "+regionLabel(region)+" → "+displayPlaceName(region,child)+".";
 else target.textContent=isFilter?regionLabel(region)+" seçildi. Düz aşağıdan istəsən kəndi də seçə bilərsən.":"Ərazi dairəsi seçildi. Düz aşağıdan kəndi seçə bilərsən; boş saxlasan, ümumi qalacaq.";
}
function updateLocationVillage(kind,preferred=""){
 const isFilter=kind==="filter";
 const parent=selectedAreaGroup(kind);
 const child=$(isFilter?"locationChildFilter":"adLocationChild").value;
 const wrap=$(isFilter?"filterVillageWrap":"adLocationVillageWrap");
 const select=$(isFilter?"locationVillageFilter":"adLocationVillage");
 select.replaceChildren(new Option(isFilter?"Bütün kəndlər":"Ərazi dairəsi (ümumi)",""));
 const sub=parent==="Qabaqçöl"?findSubarea(child):null;
 wrap.hidden=!sub;
 select.disabled=!sub;
 if(sub){
  sub.places.forEach(place=>select.append(new Option(place+" kəndi",place)));
  if(preferred&&[...select.options].some(o=>o.value===preferred))select.value=preferred;
 }
 locationAreaNote(kind);
}
function updateLocationChildren(kind,preferred="",preferredVillage=""){
 const isFilter=kind==="filter";
 const parent=selectedAreaGroup(kind);
 const wrap=$(isFilter?"filterChildWrap":"adLocationChildWrap");
 const select=$(isFilter?"locationChildFilter":"adLocationChild");
 const region=findRegion(parent);
 // Valideyn dəyişən kimi köhnə kəndlər silinir; heç bir kənd öz-özünə açılmır.
 select.replaceChildren(new Option(isFilter?"Düz aşağıdan seçim et":"Buradan seçim et",""));
 wrap.hidden=!region;
 select.disabled=!region;
 if(!region){updateLocationVillage(kind);return}
 if(parent==="Qabaqçöl"){
  select.append(new Option(isFilter?"Bütün Qabaqçöl və ətrafı":"Qabaqçöl üzrə ümumi",""));
  select.append(new Option("Qabaqçöl qəsəbəsi","Qabaqçöl"));
  region.subareas.forEach(sub=>select.append(new Option(sub.label+" ərazi dairəsi",sub.label)));
 }else{
  select.append(new Option(isFilter?"Bütün ərazi dairəsi üzrə":"Ərazi dairəsi üzrə ümumi",""));
  region.places.forEach(place=>select.append(new Option(displayPlaceName(region,place),place)));
 }
 if(preferred&&[...select.options].some(o=>o.value===preferred))select.value=preferred;
 const heading=wrap.querySelector("label>span")||wrap.querySelector("label");
 if(heading)heading.textContent=parent==="Qabaqçöl"?"1-ci addım · Qabaqçölə aid yeri seç":isFilter?"Düz aşağıdan kəndi seç":"Düz aşağıdan kəndi / yaşayış məntəqəsini seç";
 updateLocationVillage(kind,preferredVillage);
}
function resolveLocationSelection(raw){
 if(!raw)return {parent:"",child:"",village:""};
 const value=String(raw).trim();
 if(value==="Qabaqçöl"||value==="Qabaqçöl qəsəbəsi")return {parent:"Qabaqçöl",child:"Qabaqçöl",village:""};
 if(value==="Balakən şəhəri")return {parent:"Balakən",child:"Balakən şəhəri",village:""};
 const parts=value.split(/\s*,\s*/);
 // V53-dən qalan Xalatala, Göyrüclük kimi elanlar yeni qrupda açılır.
 if(parts.length>=2){
  const area=parts[0],place=parts[1];
  if(qabaqcolSubareas.includes(area)&&findSubarea(area)?.places.includes(place))
    return {parent:"Qabaqçöl",child:area,village:place};
  const region=findRegion(area);
  if(region&&region.places.includes(place))return {parent:region.label,child:place,village:""};
 }
 for(const area of qabaqcolRegion?.subareas||[]){
  if(value===area.label)return {parent:"Qabaqçöl",child:area.label,village:""};
  if(area.places.includes(value))return {parent:"Qabaqçöl",child:area.label,village:value};
 }
 for(const region of locationTree){
  if(region.label===value)return {parent:region.label,child:"",village:""};
  if(region.places.includes(value))return {parent:region.label,child:value,village:""};
 }
 return {parent:"",child:"",village:""};
}
function storedLocation(){
 const parent=$("adLocation").value,child=$("adLocationChild").value;
 const region=findRegion(parent);if(!region)return "";
 if(region.type==="Şəhər")return "Balakən şəhəri";
 if(parent==="Qabaqçöl"){
  if(!child||child==="Qabaqçöl")return "Qabaqçöl";
  const village=$("adLocationVillage").value;
  return village&&village!==child?child+", "+village:child;
 }
 if(!child||child===parent)return parent;
 return parent+", "+child;
}
function locationMatches(value,parent,child,village=""){
 if(!parent)return true;
 const selected=resolveLocationSelection(value);
 if(parent!==selected.parent)return false;
 if(!child)return true;
 if(child!==selected.child)return false;
 if(village&&village!==selected.village)return false;
 return true;
}
function displayArea(value){
 const saved=String(value||"").trim();if(!saved)return "Balakən";
 const selected=resolveLocationSelection(saved);
 if(!selected.parent)return saved;
 if(selected.parent==="Balakən")return "Balakən şəhəri";
 if(selected.parent==="Qabaqçöl"){
  if(selected.child==="Qabaqçöl"||!selected.child)return "Qabaqçöl qəsəbəsi";
  return "Qabaqçöl ətrafı · "+selected.child+(selected.village&&selected.village!==selected.child?" · "+selected.village:"");
 }
 return selected.child&&selected.child!==selected.parent?selected.parent+" · "+selected.child:selected.parent+" kənd ərazi dairəsi";
}
// V56: İş elanlarına aid məlumatlar əlavə DB sütunu tələb etmədən
// ads.description daxilində versiyalı, oxuna bilən JSON qeyd kimi saxlanılır.


const RENT_CATEGORY="Kirayə";
const RENT_START="[BALAKEN_RENT_V1]\n",RENT_END="\n[/BALAKEN_RENT_V1]\n";
const rentKeys={type:"rentType",period:"rentPeriod",brand:"rentBrand",model:"rentModel",year:"rentYear",driver:"rentDriver",homeType:"rentHomeType",rooms:"rentRooms",area:"rentArea",furnished:"rentFurnished",equipment:"rentEquipment"};
const rentNames={home:"Ev və mənzil",car:"Avtomobil",equipment:"Avadanlıq və alətlər",other:"Digər"};
function parseRental(value){const raw=String(value||"");const end=raw.indexOf(RENT_END);if(!raw.startsWith(RENT_START)||end<0)return {rent:{},text:raw};try{return {rent:JSON.parse(raw.slice(RENT_START.length,end)),text:raw.slice(end+RENT_END.length)}}catch{return {rent:{},text:raw}}}
function rentalData(){return Object.fromEntries(Object.entries(rentKeys).map(([k,id])=>[k,$(id).disabled?"":$(id).value.trim()]))}
function updateRentalForm(){const active=$("adCategory").value===RENT_CATEGORY;$("rentalFields").hidden=!active;const type=$("rentType").value;$("rentalFields").querySelectorAll("input,select").forEach(el=>el.disabled=!active);document.querySelectorAll("[data-rent-kind]").forEach(box=>{box.hidden=!active||box.dataset.rentKind!==type;box.querySelectorAll("input,select").forEach(el=>el.disabled=box.hidden)});$("rentType").required=active;$("rentPeriod").required=active;if(active)$("adPriceLabel").textContent="Kirayə qiyməti (AZN) *";$("rentBrand").required=active&&type==="car";$("rentModel").required=active&&type==="car";}
function updateRentalFilter(){const active=($("categoryFilter").value||chosenCategory)===RENT_CATEGORY;$("rentalFilters").hidden=!active;if(!active)$("rentalFilters").querySelectorAll("input,select").forEach(el=>el.value="");$("rentFilterCar").hidden=$("rentFilterType").value!=="car";$("rentFilterHome").hidden=$("rentFilterType").value!=="home";}
function rentalMatches(a){if(($("categoryFilter").value||chosenCategory)!==RENT_CATEGORY)return true;const r=parseRental(a.description).rent;return (!$("rentFilterType").value||r.type===$("rentFilterType").value)&&(!$("rentFilterPeriod").value||r.period===$("rentFilterPeriod").value)&&($("rentFilterType").value!=="car"||[ ["rentFilterBrand","brand"],["rentFilterModel","model"] ].every(([id,key])=>!$(id).value||fuzzyTextMatch($(id).value,[r[key]])))&&($("rentFilterType").value!=="home"||!$("rentFilterRooms").value||String(r.rooms)===$("rentFilterRooms").value);}
function rentalDetail(a){if(a.category!==RENT_CATEGORY)return null;const p=parseRental(a.description),r=p.rent;const fields=[["Kirayə növü",rentNames[r.type]],["Müddət",r.period==="month"?"Aylıq":"Günlük"],...(r.type==="car"?[["Marka",r.brand],["Model",r.model],["İl",r.year],["Sürücü",r.driver]]:r.type==="home"?[["Evin növü",r.homeType],["Otaq sayı",r.rooms],["Sahəsi (m²)",r.area],["Əşyalar",r.furnished]]:[["Avadanlığın növü",r.equipment]])].filter(([,v])=>v);return {info:'<section class="job-detail-info"><h3>Kirayə haqqında</h3>'+fields.map(([k,v])=>`<div class="job-detail-row"><strong>${escapeHtml(k)}:</strong><span>${escapeHtml(v)}</span></div>`).join("")+"</section>",description:p.text||"Əlavə açıqlama yoxdur."};}

const CAR_CATEGORY="Avtomobil";
const CAR_START="[BALAKEN_CAR_V1]\n",CAR_END="\n[/BALAKEN_CAR_V1]\n";
function parseCarDescription(value){
 const raw=String(value||"");
 if(!raw.startsWith(CAR_START))return {car:null,text:raw};
 const end=raw.indexOf(CAR_END,CAR_START.length);
 if(end<0)return {car:null,text:raw};
 try{return {car:JSON.parse(raw.slice(CAR_START.length,end)),text:raw.slice(end+CAR_END.length)}}catch{return {car:null,text:raw}}
}
function carData(){return {brand:$("carBrand").value.trim(),model:$("carModel").value.trim(),year:$("carYear").value,color:$("carColor").value,engine:$("carEngine").value,power:$("carPower").value,mileage:$("carMileage").value,gearbox:$("carGearbox").value}}
function updateCarTitle(){const c=carData();$("adTitle").value=[c.brand,c.model,c.year].filter(Boolean).join(" ")}
function updateCarForm(){
 updateRentalForm();
 const active=$("adCategory").value===CAR_CATEGORY;
 $("carFields").hidden=!active;$("adTitleWrap").hidden=active;$("adTitle").required=!active;
 ["carBrand","carModel","carYear"].forEach(id=>$(id).required=active);
 if(active)updateCarTitle();
 syncAdCategoryLayout();
}

function syncAdCategoryLayout(){
 const category=$("adCategory").value,chosen=Boolean(category);
 $("adCategoryDependent").hidden=!chosen;$("adCategoryDependent").disabled=!chosen;
 const names={"Heyvanlar":["Heyvanın adı *","Məsələn: inək, qoyun"],"İş elanları":["İşin adı *","Məsələn: elektrikçi"],"Xidmətlər":["Xidmətin adı *","Məsələn: kombi təmiri"],"Ev və torpaq":["Əmlakın adı *","Məsələn: həyət evi"],"Kirayə":["Kirayə verilənin adı *","Məsələn: ev, avtomobil, alət"]};
 const [label,hint]=names[category]||["Əşyanın adı *","Məsələn: soyuducu, telefon, divan"];
 $("adTitleLabel").textContent=label;$("adTitle").placeholder=hint;
 if(category===RENT_CATEGORY)$("adPriceLabel").textContent="Kirayə qiyməti (AZN / "+($("rentPeriod").value==="month"?"ay":"gün")+") *";
}

function buildCarDescription(){return CAR_START+JSON.stringify(carData())+CAR_END+$("adDescription").value.trim()}
function carDetailMarkup(a){
 if(a.category!==CAR_CATEGORY)return null;
 const p=parseCarDescription(a.description);if(!p.car)return null;
 const c=p.car;
 const fields=[["Marka",c.brand],["Model",c.model],["İl",c.year],["Rəng",c.color],["Mühərrik",c.engine?c.engine+" L":""],["Güc",c.power?c.power+" a.g.":""],["Yürüş",c.mileage?Number(c.mileage).toLocaleString("az-AZ")+" km":""],["Sürətlər qutusu",c.gearbox]].filter(([,v])=>v);
 return {info:`<section class="job-detail-info"><h3>🚗 Avtomobil haqqında</h3>${fields.map(([k,v])=>`<div class="job-detail-row"><strong>${escapeHtml(k)}:</strong><span>${escapeHtml(v)}</span></div>`).join("")}</section>`,description:p.text||"Əlavə açıqlama yoxdur."};
}

const JOB_CATEGORY="İş elanları";
const JOB_START="[BALAKEN_JOB_V1]\n", JOB_END="\n[/BALAKEN_JOB_V1]\n";
const JOB_KEYS=["jobType","jobWorkplace","jobSchedule","jobExperience","jobEducation","jobRequirements"];
function parseJobDescription(value){
 const raw=String(value||"");
 if(!raw.startsWith(JOB_START))return {job:null,text:raw};
 const end=raw.indexOf(JOB_END,JOB_START.length);
 if(end<0)return {job:null,text:raw};
 try{
  const job=JSON.parse(raw.slice(JOB_START.length,end));
  if(!job||typeof job!=="object"||!["worker","seeker"].includes(job.type))return {job:null,text:raw};
  return {job,text:raw.slice(end+JOB_END.length)};
 }catch{return {job:null,text:raw}}
}
function buildJobDescription(){
 const job={type:$("jobType").value,workplace:$("jobWorkplace").value.trim(),schedule:$("jobSchedule").value,experience:$("jobExperience").value,education:$("jobEducation").value,requirements:$("jobRequirements").value.trim()};
 return JOB_START+JSON.stringify(job)+JOB_END+$("adDescription").value.trim();
}
function jobTypeLabel(type){return type==="worker"?"İşçi axtarılır":type==="seeker"?"İş axtarılır":"İş elanı"}
function formatAdPrice(a){
 const amount=Number(a.price||0);
 if(a.category===JOB_CATEGORY)return "";
 if(a.category===RENT_CATEGORY)return `${amount.toLocaleString("az-AZ")} AZN / ${parseRental(a.description).rent.period==="month"?"ay":"gün"}`;
 return `${amount.toLocaleString("az-AZ")} AZN`;
}
function updateJobFilter(){
 updateRentalFilter();updateSaleCarFilter();
 const category=$("categoryFilter").value||chosenCategory;
 const active=category===JOB_CATEGORY;
 $("categoryDependentFilters").hidden=!category;
 for(const id of ["minPriceFilter","maxPriceFilter"]){$(id).closest("label").hidden=active;if(active||!category)$(id).value="";}
 const period=$("rentFilterPeriod").value;
 const unit=category===RENT_CATEGORY?(period==="day"?"AZN / gün":period==="month"?"AZN / ay":"AZN · günlük/aylıq"):"AZN";
 $("minPriceLabel").textContent="Minimum qiymət · "+unit;$("maxPriceLabel").textContent="Maksimum qiymət · "+unit;
 $("jobFilterWrap").hidden=!active;
 $("jobTypeFilter").disabled=!active;
 if(!active)$("jobTypeFilter").value="";
}
function updateJobForm(){
 const active=$("adCategory").value===JOB_CATEGORY;
 $("jobFields").hidden=!active;
 $("jobType").required=active;
 $("adPriceWrap").hidden=active;
 $("adPrice").required=!active;
 if(active)$("adPrice").value="0";
 $("adPriceLabel").textContent="Qiymət (AZN) *";
 $("adDescription").placeholder=active?"İş barədə əlavə məlumat":"Məhsulun vəziyyəti və digər məlumatlar";
}
function jobDetailMarkup(a){
 if(a.category!==JOB_CATEGORY)return {info:"",description:a.description||"Təsvir əlavə edilməyib."};
 const parsed=parseJobDescription(a.description);
 if(!parsed.job)return {info:"",description:parsed.text||"Təsvir əlavə edilməyib."};
 const j=parsed.job;
 const fields=[["Elanın növü",jobTypeLabel(j.type)],["İş yeri",j.workplace],["İş qrafiki",j.schedule],["Təcrübə",j.experience],["Təhsil",j.education],["İş tələbləri",j.requirements]].filter(([k,v])=>v);
 return {info:`<section class="job-detail-info"><h3>💼 İş haqqında</h3>${fields.map(([k,v])=>`<div class="job-detail-row"><strong>${escapeHtml(k)}:</strong><span>${escapeHtml(v)}</span></div>`).join("")}</section>`,description:parsed.text||"Əlavə açıqlama yoxdur."};
}
function fillCategories(){
 const categories=window.BALAKEN_CATEGORIES||[];
 $("categoryFilter").innerHTML='<option value="">Bütün kateqoriyalar</option>';
 $("adCategory").innerHTML='<option value="">Kateqoriya seç</option>';
 categories.forEach(c=>{const a=document.createElement("option");a.value=c.name;a.textContent=c.name;$("categoryFilter").append(a);const b=a.cloneNode(true);$("adCategory").append(b)});
 $("categories").innerHTML="";
 const categoryPictures={
  "Elektrik və ev əşyaları":"elektrik-ev.webp",
  "Telefon və elektronika":"telefon-elektronika.webp",
  "Mebel":"mebel.webp",
  "Avtomobil":"avtomobil.webp",
  "Ev və torpaq":"ev-torpaq.webp",
  "Heyvanlar":"heyvanlar.webp",
  "Geyim və ayaqqabı":"geyim.webp",
  "İş elanları":"is-elanlari.webp",
  "Xidmətlər":"xidmetler.webp",
  "Digər":"diger.webp"
 };
 categories.forEach(c=>{
  const el=document.createElement("button");el.type="button";el.className="category";if(c.name===RENT_CATEGORY)el.classList.add("rental-category");
  const photo=categoryPictures[c.name];
  const visual=c.name===RENT_CATEGORY?`<span class="rental-category-art" aria-hidden="true"><svg viewBox="0 0 240 130" fill="none"><circle cx="120" cy="66" r="48" fill="white" fill-opacity=".12"/><path d="M48 65L79 40L110 65V97H88V76H71V97H48Z" fill="#d5f4e7"/><rect x="132" y="79" width="63" height="19" rx="7" fill="#b6e8e1"/><path d="M144 79L151 66H176L186 79" stroke="#b6e8e1" stroke-width="7" stroke-linejoin="round"/><circle cx="147" cy="99" r="6" fill="#eafff6"/><circle cx="181" cy="99" r="6" fill="#eafff6"/><circle cx="128" cy="43" r="14" stroke="#ffd772" stroke-width="8"/><path d="M119 54L99 74M106 67L113 74M100 73L106 79" stroke="#ffd772" stroke-width="8" stroke-linecap="round"/></svg></span>`:photo?`<span class="category-photo"><img loading="lazy" decoding="async" src="assets/categories/${photo}" alt=""></span>`:`<span class="emoji" aria-hidden="true">${c.emoji}</span>`;
  el.innerHTML=`${visual}<strong>${escapeHtml(c.name)}</strong>`;
  el.setAttribute("aria-label",c.name);
  const img=el.querySelector(".category-photo img");
  if(img)img.addEventListener("error",()=>{img.parentElement.textContent=c.emoji});
  el.addEventListener("click",()=>{chosenCategory=c.name;$("categoryFilter").value=c.name;document.querySelectorAll(".category").forEach(x=>x.classList.toggle("active",x===el));updateJobFilter();renderAds()});
  $("categories").append(el);
 });
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function escapeAttr(s=""){return escapeHtml(s)}
function configNotice(){
 const el=$("statusMessage");
 if(!db){el.hidden=false;el.textContent="Sayt Supabase-ə qoşulmayıb. js/config.js faylında layihə URL-i və publishable key-i yoxla."}
 else {el.hidden=true;el.textContent=""}
}
async function refreshSession(){
 if(!db)return;
 // Register the listener before reading the session to avoid missing an OAuth sign-in event.
 db.auth.onAuthStateChange((event,s)=>{
   session=s;currentUser=s?.user||null;
   if(event === "PASSWORD_RECOVERY"){
     passwordRecoveryActive=true;
     setTimeout(()=>{
       $("authModal").querySelector(".optional-auth").open=true;
       setEmailAuthMode("recovery");
       showModal("authModal");
       emailAuthNotice("Yeni şifrəni yazıb yadda saxla.","success");
     },0);
   }
   setTimeout(async()=>{
     await updateAccount();
     await loadAds();
     if(event === "SIGNED_IN" && !passwordRecoveryActive){
       closeModal("authModal");
       toast("Hesaba daxil oldun.");
     } else if(event === "SIGNED_OUT") {
       passwordRecoveryActive=false;
       toast("Hesabdan çıxış edildi.");
     }
   },0);
 });
 const {data,error}=await db.auth.getSession();
 if(error) console.error("Sessiya alınmadı:",error);
 session=data?.session||null;currentUser=session?.user||null;
 await updateAccount();
 if(currentUser && sessionStorage.getItem("openAdAfterLogin")==="1"){
   sessionStorage.removeItem("openAdAfterLogin");
   closeModal("authModal");showModal("adModal");
 }
}
async function profile(){
 if(!db||!currentUser)return null;
 const {data,error}=await db.from("profiles").select("username,is_admin,role").eq("user_id",currentUser.id).maybeSingle();
 if(error){console.error(error);return null}return data;
}
async function updateAccount(){
 const panel=$("accountPanel");
 const authButton=$("authOpen");
 if(!db||!currentUser){
   accountView=false;adminLandingUser=null;
   panel.hidden=true;$("adminPanel").hidden=true;$("myAdsPanel").hidden=true;
   $("adminPanel").dataset.staff="no";
   if(authButton){authButton.textContent="Daxil ol / Qeydiyyat";}
   setAccountView(false);
   return;
 }
 const p=await profile();
 const meta=currentUser.user_metadata||{};
 const visibleName=p?.username||meta.username||meta.full_name||meta.name||currentUser.email?.split("@")[0]||"istifadəçi";
 $("accountInfo").textContent=`İstifadəçi: ${visibleName}`;
 // Server-side owner UUID is authoritative; an email string is not a permission.
 const checkedUser=currentUser.id;
 const {data:ownerAccess,error:ownerError}=await db.rpc("is_staff");
 if(currentUser?.id!==checkedUser)return;
 const isStaff=!ownerError&&ownerAccess===true;
 $("adminPanel").dataset.staff=isStaff?"yes":"no";
 $("adminIdentity").textContent=currentUser.email||visibleName;
 if(isStaff&&adminLandingUser!==checkedUser&&!passwordRecoveryActive){
  accountView=true;adminLandingUser=checkedUser;
  sessionStorage.removeItem("openAdAfterLogin");
 }
 setAccountView(accountView);
 if(isStaff){await loadAdminUsers(1);await loadReports();await loadSupportAdmin();await loadAdminAds(true);await loadAdminBanners();}
 else await loadMyAds();
}
async function loadMyAds(){
 if(!db||!currentUser||$("adminPanel").dataset.staff==="yes")return;
 const {data,error}=await db.from("ads").select("id,title,status,created_at,expires_at,price,location").eq("user_id",currentUser.id).order("created_at",{ascending:false}).limit(100);
 const list=$("myAdsList");list.innerHTML="";
 if(error){list.textContent="Elanlar yüklənmədi: "+error.message;return}
 if(!data?.length){list.innerHTML='<div class="empty">Hələ elan yerləşdirməmisən.</div>';return}
 data.forEach(a=>{
  const item=document.createElement("div");item.className="report-item";
  const statusLabel=({published:"Aktiv",removed:"Silinib",expired:"Müddəti bitib",pending:"Yoxlanılır",rejected:"Rədd edilib",archived:"Arxivdə"})[a.status]||a.status;
  item.innerHTML=`<strong>${escapeHtml(a.title)}</strong><p>${escapeHtml(formatAdPrice(a))} · ${escapeHtml(a.location)}</p><small>Status: ${escapeHtml(statusLabel)} · Bitmə tarixi: ${a.expires_at?new Date(a.expires_at).toLocaleDateString("az-AZ"):"—"}</small><div class="product-actions"><button class="btn outline" data-my-edit="${a.id}">Redaktə et</button>${["expired","published"].includes(a.status)?`<button class="btn outline" data-my-renew="${a.id}">2 ay uzat</button>`:""}<button class="btn outline" data-my-delete="${a.id}">Sil</button></div>`;
  list.append(item);
 });
 list.querySelectorAll("[data-my-edit]").forEach(b=>b.addEventListener("click",()=>editAd(b.dataset.myEdit)));
 list.querySelectorAll("[data-my-renew]").forEach(b=>b.addEventListener("click",()=>renewAd(b.dataset.myRenew)));
 list.querySelectorAll("[data-my-delete]").forEach(b=>b.addEventListener("click",()=>deleteAd(b.dataset.myDelete)));
}
async function loadAds(){
 if(!db){ads=[];renderAds();configNotice();return}
 const {data,error}=await db.from("ads").select("*").in("status",["published","active"]).or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`).order("featured_until",{ascending:false,nullsFirst:false}).order("created_at",{ascending:false}).limit(1000);
 if(error){
   console.error("Elanların yüklənməsi xətası:",error);
   toast("Elanlar yüklənmədi. Supabase SQL düzəlişini tətbiq et: "+error.message);
   ads=[];renderAds();return;
 }
 ads=data||[];
 if(ads.length){
  const {data:media,error:mediaError}=await db.from("ad_media").select("ad_id,media_url,sort_order").eq("media_type","image").in("ad_id",ads.map(a=>a.id)).order("sort_order",{ascending:true});
  if(mediaError) console.warn("Əlavə şəkillər oxunmadı:",mediaError.message);
  const grouped={};(media||[]).forEach(m=>{(grouped[m.ad_id] ||= []).push(m.media_url)});
  ads=ads.map(a=>({...a,images:[...new Set([a.image_url,...(grouped[a.id]||[])].filter(Boolean))]}));
 }
 renderAds();
 loadSiteBanners();
 const linkedAd=new URLSearchParams(location.search).get("ad");
 if(linkedAd){history.replaceState({},document.title,location.pathname);openAdDetails(linkedAd);}
}
function searchText(value=""){
 return String(value).toLocaleLowerCase("az").normalize("NFD")
  .replace(/[\u0300-\u036f]/g,"").replace(/ı/g,"i").replace(/ə/g,"e")
  .replace(/ş/g,"s").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ö/g,"o").replace(/ü/g,"u")
  .replace(/[^a-z0-9]+/g," ").trim();
}
function digitsOnly(value=""){return String(value).replace(/\D/g,"")}
function editDistance(a,b){
 if(a===b)return 0;if(!a.length)return b.length;if(!b.length)return a.length;
 let prev=Array.from({length:b.length+1},(_,i)=>i);
 for(let i=1;i<=a.length;i++){
  const cur=[i];
  for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));
  prev=cur;
 }
 return prev[b.length];
}
function fuzzyTextMatch(query, fields){
 const qText=searchText(query);if(!qText)return true;
 const qDigits=digitsOnly(query);
 if(qDigits.length>=5 && fields.some(v=>digitsOnly(v).includes(qDigits)))return true;
 const all=fields.map(searchText).filter(Boolean);
 if(all.some(v=>v.includes(qText)))return true;
 const queryWords=qText.split(/\s+/).filter(Boolean);
 return queryWords.every(word=>{
  if(word.length<3)return all.some(v=>v.split(/\s+/).includes(word));
  const maxDistance=word.length>=6?2:1;
  return all.some(v=>v.split(/\s+/).some(candidate=>candidate===word || (Math.abs(candidate.length-word.length)<=maxDistance && editDistance(word,candidate)<=maxDistance)));
 });
}
function openGallery(ad){
 galleryImages=[...new Set([...(ad.images||[]),ad.image_url].filter(Boolean))];
 if(!galleryImages.length)return;
 galleryIndex=0;
 const modal=$("imageModal");
 $("galleryTitle").textContent=ad.title||"Elan şəkilləri";
 renderGalleryImage();
 modal.hidden=false;
}
function renderGalleryImage(){
 if(!galleryImages.length)return;
 $("galleryImage").src=galleryImages[galleryIndex];
 $("galleryImage").alt=$("galleryTitle").textContent||"Elan şəkli";
 $("galleryCounter").textContent=`${galleryIndex+1} / ${galleryImages.length}`;
 $("galleryPrev").disabled=galleryImages.length<2;
 $("galleryNext").disabled=galleryImages.length<2;
}
$("galleryPrev").addEventListener("click",()=>{if(galleryImages.length>1){galleryIndex=(galleryIndex-1+galleryImages.length)%galleryImages.length;renderGalleryImage()}});
$("galleryNext").addEventListener("click",()=>{if(galleryImages.length>1){galleryIndex=(galleryIndex+1)%galleryImages.length;renderGalleryImage()}});
$("galleryClose").addEventListener("click",()=>{$("imageModal").hidden=true});
$("imageModal").addEventListener("click",e=>{if(e.target===$("imageModal"))$("imageModal").hidden=true});
let adsPage=1;
function renderAds(options){
 if(!options || options.keepPage!==true)adsPage=1;
 const q=$("searchInput").value.trim();
 const itemQuery=$("itemFilter").value.trim();
 const loc=$("locationFilter").value, cat=$("categoryFilter").value||chosenCategory;
 const jobTypeFilter=cat===JOB_CATEGORY?$("jobTypeFilter").value:"";
 const minInput=$("minPriceFilter").value, maxInput=$("maxPriceFilter").value;
 const minPrice=minInput===""?null:Number(minInput),maxPrice=maxInput===""?null:Number(maxInput);
 const filtered=ads.filter(a=>fuzzyTextMatch(q,[a.title,a.description,a.category,a.location,a.phone,a.seller_name])&&locationMatches(a.location,loc,$("locationChildFilter").value,$("locationVillageFilter").value)&&(!cat||a.category===cat)
  &&(!itemQuery||fuzzyTextMatch(itemQuery,[a.title,a.description]))&&saleCarMatches(a)&&rentalMatches(a)
  &&(!jobTypeFilter||(a.category===JOB_CATEGORY&&parseJobDescription(a.description).job?.type===jobTypeFilter))
  &&(minPrice===null||Number(a.price)>=minPrice)&&(maxPrice===null||Number(a.price)<=maxPrice));
 const sort=$("sortFilter").value;
 if(sort==="priceAsc")filtered.sort((a,b)=>Number(a.price)-Number(b.price));
 else if(sort==="priceDesc")filtered.sort((a,b)=>Number(b.price)-Number(a.price));
 $("resultsCount").textContent=`${filtered.length} elan`;
 $("products").innerHTML="";
 $("adsPagination").replaceChildren();$("adsPagination").hidden=true;
 if(!filtered.length){$("products").innerHTML='<div class="empty">Bu axtarışa uyğun elan tapılmadı.</div>';return}
 const pageData=window.BalakenPagination.slice(filtered,adsPage);adsPage=pageData.page;
 window.BalakenPagination.render($("adsPagination"),filtered.length,adsPage,page=>{adsPage=page;renderAds({keepPage:true});$("homeAdsPanel").scrollIntoView({block:"start"});});
 pageData.items.forEach(a=>{
  const el=document.createElement("article");el.className="product";el.tabIndex=0;el.setAttribute("role","link");el.setAttribute("aria-label",a.title);
  el.addEventListener("click",()=>openAdDetails(a.id));
  el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openAdDetails(a.id)}});
  const firstImage=(a.images&&a.images[0])||a.image_url;
  const image=firstImage?`<img loading="lazy" src="${escapeAttr(firstImage)}" alt="${escapeAttr(a.title)}">`:escapeHtml((window.BALAKEN_CATEGORIES.find(c=>c.name===a.category)||{}).emoji||"📦");
  const imageCount=(a.images||[]).length;
  el.innerHTML=`<div class="product-img">${image}${imageCount>1?`<span class="image-count">📷 ${imageCount} şəkil</span>`:""}</div><div class="product-body"><span class="card-location">📍 ${escapeHtml(displayArea(a.location))}</span><h3 translate="no">${escapeHtml(a.title)}</h3>${a.category===JOB_CATEGORY?`<p class="job-card-kind">💼 ${escapeHtml(jobTypeLabel(parseJobDescription(a.description).job?.type))}</p>`:""}${a.category===JOB_CATEGORY?"":`<p class="price">${escapeHtml(formatAdPrice(a))}</p>`}</div>`;
  $("products").append(el);
 });
 $("products").querySelectorAll("[data-open-ad]").forEach(b=>b.addEventListener("click",e=>{e.preventDefault();e.stopPropagation();openAdDetails(b.dataset.openAd);}));
}
function openAdDetails(adId){
 const a=ads.find(item=>String(item.id)===String(adId));
 if(!a){toast("Elan məlumatı tapılmadı. Səhifəni yenilə.");return}
 const photos=[...new Set([a.image_url,...(a.images||[])].filter(Boolean))];
 const sellerName=(a.seller_name||"").trim()||"İstifadəçi";
 const created=a.created_at?new Date(a.created_at).toLocaleDateString("az-AZ"):"—";
 const phone=(a.phone||"").trim();
 const jobDetail=rentalDetail(a)||carDetailMarkup(a)||jobDetailMarkup(a);
 const photoMarkup=photos.length
  ? `<div class="ad-detail-photos">${photos.map((url,i)=>`<img src="${escapeAttr(url)}" alt="${escapeAttr(a.title)} — şəkil ${i+1}" data-detail-photo="${i}" class="${i===0?"active":""}">`).join("")}</div>${photos.length>1?`<div class="ad-detail-thumbs">${photos.map((url,i)=>`<button type="button" data-detail-thumb="${i}" class="${i===0?"active":""}" aria-label="${i+1}-ci şəkil"><img src="${escapeAttr(url)}" alt=""></button>`).join("")}</div>`:""}`
  : `<div class="ad-detail-no-photo">${escapeHtml((window.BALAKEN_CATEGORIES.find(c=>c.name===a.category)||{}).emoji||"📦")} Şəkil əlavə edilməyib</div>`;
 const sellerIdentity=a.user_id?`seller=${encodeURIComponent(a.user_id)}`:`sellerName=${encodeURIComponent((a.seller_name||"").trim())}`;
 const sellerUrl=`seller-ads.html?${sellerIdentity}&name=${encodeURIComponent(sellerName)}&fromAd=${encodeURIComponent(a.id)}`;
 const similarAds=ads.filter(item=>String(item.id)!==String(a.id)&&((a.category&&item.category===a.category)||(a.location&&item.location===a.location))).slice(0,8);
 const miniAd=(item)=>{const img=(item.images&&item.images[0])||item.image_url;return `<a class="related-ad" href="index.html?ad=${encodeURIComponent(item.id)}"><div class="related-ad-image">${img?`<img src="${escapeAttr(img)}" alt="${escapeAttr(item.title)}">`:`<span>${escapeHtml((window.BALAKEN_CATEGORIES.find(c=>c.name===item.category)||{}).emoji||"📦")}</span>`}</div><div class="related-ad-body"><strong translate="no">${escapeHtml(item.title||"Elan")}</strong><p class="price">${escapeHtml(formatAdPrice(item))}</p></div></a>`};
 $("adDetailContent").innerHTML=`${photoMarkup}<div class="ad-detail-info"><h2 translate="no">${escapeHtml(a.title)}</h2>${a.category===JOB_CATEGORY?"":`<p class="price">${escapeHtml(formatAdPrice(a))}</p>`}<p><strong>Ərazi:</strong> ${escapeHtml(displayArea(a.location))}</p><p><strong>Kateqoriya:</strong> ${escapeHtml(a.category||"—")}</p><p><strong>Elanın tarixi:</strong> ${escapeHtml(created)}</p><p><strong>Elanı yerləşdirən:</strong> ${escapeHtml(sellerName)}</p>${jobDetail.info}<h3>Elanın təsviri</h3><p translate="no" class="ad-detail-description">${escapeHtml(jobDetail.description)}</p><div class="product-actions">${phone?`<a class="btn green" href="tel:${escapeAttr(phone)}">☎ Telefon nömrəsi: ${escapeHtml(phone)}</a>`:"<p>Telefon nömrəsi göstərilməyib.</p>"}<button class="report-btn" type="button" data-detail-report="${escapeAttr(a.id)}">Şikayət et</button></div></div>
 <section class="detail-related-section seller-all-ads"><a class="btn green" href="${sellerUrl}">Elan sahibinin bütün elanları</a></section>
 <section class="detail-related-section similar-section"><h3>Oxşar elanlar</h3>${similarAds.length?`<div class="related-ads-grid">${similarAds.map(miniAd).join("")}</div>`:`<p class="related-empty">Hazırda oxşar elan yoxdur.</p>`}</section>`;

 $("adDetailContent").querySelectorAll("[data-detail-thumb]").forEach(b=>b.addEventListener("click",()=>{
  const index=Number(b.dataset.detailThumb);
  $("adDetailContent").querySelectorAll("[data-detail-photo]").forEach(img=>img.classList.toggle("active",Number(img.dataset.detailPhoto)===index));
 }));
 // Əsas şəkilə basanda böyük şəkil pəncərəsi açılır.
 document.querySelectorAll("#adDetailContent [data-detail-photo]").forEach(img=>img.addEventListener("click",()=>{
  galleryImages=photos;
  galleryIndex=Number(img.dataset.detailPhoto)||0;
  $("galleryTitle").textContent=a.title||"Elan şəkilləri";
  renderGalleryImage();
  $("imageModal").hidden=false;
 }));
 document.querySelectorAll("#adDetailContent [data-detail-thumb]").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll("#adDetailContent [data-detail-thumb]").forEach(x=>x.classList.toggle("active",x===b));
 }));
 const report=$("adDetailContent").querySelector("[data-detail-report]");
 if(report)report.addEventListener("click",()=>reportAd(report.dataset.detailReport));
 showModal("adDetailModal");
}
$("authOpen").addEventListener("click",()=>{
 if(!currentUser){showModal("authModal");return}
 setAccountView(!accountView);
});
$("adminHomeBack").addEventListener("click",()=>setAccountView(false));
$("adminSignOut").addEventListener("click",()=>$("signOut").click());
$("homeBack").addEventListener("click",()=>setAccountView(false));
$("newAdOpen").addEventListener("click",()=>{
 if(!currentUser){sessionStorage.setItem("openAdAfterLogin","1");showModal("authModal");return}
 resetAdForm();showModal("adModal");
});
// V65: Şifrəni göstər/gizlət düyməsi həm qeydiyyatda, həm girişdə, həm də şifrə bərpasında işləyir.
function setPasswordVisibility(visible){
 const input=$("authPassword"),button=$("toggleAuthPassword");
 input.type=visible?"text":"password";
 const label=visible?"Şifrəni gizlət":"Şifrəni göstər";
 button.setAttribute("aria-label",label);
 button.setAttribute("title",label);
 button.setAttribute("aria-pressed",String(visible));
 button.querySelector(".eye-visible-icon").hidden=visible;
 button.querySelector(".eye-hidden-icon").hidden=!visible;
}
$("toggleAuthPassword").addEventListener("click",()=>setPasswordVisibility($("authPassword").type==="password"));
// V64: Qeydiyyat və giriş bir-birindən vizual ayrılıb.
// Supabase xətası hesabın mövcudluğunu aşkar etmədən izah edilir.
function setEmailAuthMode(mode){
 setPasswordVisibility(false);
 const recovery=mode==="recovery",signUp=mode==="signup";
 $("authEmail").readOnly=false;
 $("authPasswordWrap").hidden=false;
 $("emailConfirmCodeWrap").hidden=true;
 $("confirmEmailCode").hidden=true;
 $("authConfirmCode").value="";
 const tabs=$("emailAuthModeTabs");
 tabs.hidden=recovery;
 $("authUsernameWrap").hidden=!signUp;
 $("authEmailWrap").hidden=recovery;
 $("emailSignUp").hidden=!signUp;
 $("emailSignIn").hidden=recovery||signUp;
 // Yeni hesab yaradarkən göndərilmiş təsdiq linki telefonda açıla bilər.
 // Bu düymə yalnız qeydiyyat sorğusundan sonra göstərilir.
 $("emailSignInAfterConfirm").hidden=true;
 $("authSaveNewPassword").hidden=!recovery;
 $("forgotAuthPassword").hidden=recovery||signUp;
 $("resendConfirmEmail").hidden=recovery||signUp;
 $("authPasswordLabel").textContent=recovery?"Yeni şifrə":"Şifrə";
 $("authPassword").placeholder=recovery?"Yeni şifrə (ən azı 8 simvol)":"Ən azı 8 simvol";
 $("authPassword").autocomplete=signUp||recovery?"new-password":"current-password";
 $("emailAuthModeHint").textContent=recovery?"Yeni şifrən ən azı 8 simvol olmalıdır.":signUp?"İlk dəfə daxil olursansa, əvvəl yeni hesab yarat.":"Artıq hesab yaratmısansa, e-poçtunu və şifrəni yaz. Yoxdursa, Yeni hesab yarat seç.";
 [["authModeSignUp",signUp],["authModeSignIn",!signUp&&!recovery]].forEach(([id,active])=>{
   $(id).classList.toggle("selected",active);
   $(id).setAttribute("aria-pressed",String(active));
 });
 emailAuthNotice("");
}
$("authModeSignUp").addEventListener("click",()=>setEmailAuthMode("signup"));
$("authModeSignIn").addEventListener("click",()=>setEmailAuthMode("signin"));
setEmailAuthMode("signup");
// V102: Supabase-in göndərdiyi 6 və ya 8 rəqəmli təsdiq kodu qəbul edilir.
function showEmailCodeForm(email){
 if(email)$("authEmail").value=email;
 $("authEmail").readOnly=true;
 $("authUsernameWrap").hidden=true;
 $("authPasswordWrap").hidden=true;
 $("emailConfirmCodeWrap").hidden=false;
 $("confirmEmailCode").hidden=false;
 $("emailSignUp").hidden=true;
 $("emailSignIn").hidden=true;
 $("emailSignInAfterConfirm").hidden=true;
 $("resendConfirmEmail").hidden=false;
 $("emailAuthModeHint").textContent="Gmail-ə gələn kodu daxil et.";
 $("authConfirmCode").focus();
}
// V63: e-poçtla giriş/qeydiyyat üçün konkret və aydın xəta bildirişləri.
function emailAuthNotice(message,kind="error"){
 const el=$("emailAuthMessage");
 if(el){el.textContent=message;el.dataset.kind=kind;el.hidden=!message}
 else if(message)toast(message);
}
function cleanAuthEmail(){return $("authEmail").value.trim()}
function validAuthEmail(){
 const input=$("authEmail"),email=cleanAuthEmail();
 if(!email){emailAuthNotice("E-poçt ünvanını yaz.");input.focus();return null}
 // Brauzer səviyyəsində və ayrıca domendə nöqtə olub-olmadığını yoxla.
 if(!input.validity.valid||! /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)){
  emailAuthNotice("E-poçt düzgün yazılmayıb. Məsələn: ad@gmail.com");input.focus();return null;
 }
 return email;
}
function validUsername(){
 const username=$("authUsername").value.trim();
 if(!/^[A-Za-zƏəĞğİıÖöŞşÇçÜü0-9_]{3,24}$/.test(username)){
  emailAuthNotice("İstifadəçi adı 3–24 simvol olmalı, Azərbaycan hərfləri, ingilis hərfləri, rəqəm və _ işarəsindən ibarət olmalıdır.");
  $("authUsername").focus();return null;
 }
 return username;
}
function authFieldsValid(){
 const username=validUsername();if(!username)return null;
 const email=validAuthEmail();if(!email)return null;
 const password=$("authPassword").value;
 if(password.length<8){emailAuthNotice("Şifrə ən azı 8 simvol olmalıdır.");$("authPassword").focus();return null}
 return {username,email,password};
}
function describeEmailAuthError(error,kind="signup"){
 const code=String(error?.code||"").toLowerCase();
 const message=String(error?.message||"").toLowerCase();
 if(code==="email_address_not_authorized"||message.includes("email address not authorized"))
  return "Bu ünvana təsdiq məktubu göndərilə bilmir. Saytın e-poçt göndərmə xidməti hələ qurulmayıb. Sayt rəhbərliyi ilə əlaqə saxla.";
 if(code==="email_address_invalid"||message.includes("email address is invalid")||message.includes("invalid email"))
  return "Bu e-poçt ünvanı qəbul edilmir. Düzgün, işlək e-poçt ünvanı daxil et. Düzgündürsə, saytın e-poçt xidməti yoxlanmalıdır.";
 if(code==="signup_disabled"||code==="email_provider_disabled"||message.includes("signups not allowed"))
  return "E-poçtla qeydiyyat saytın serverində aktiv deyil. Sayt rəhbərliyi bu funksiyanı aktivləşdirməlidir.";
 if(code==="over_email_send_rate_limit"||code==="over_request_rate_limit"||code==="too_many_requests"||message.includes("rate limit"))
  return "Qısa vaxtda çox sorğu göndərilib. Bir müddət sonra yenidən cəhd et.";
 if(code==="user_already_exists"||code==="email_exists"||message.includes("already registered")||message.includes("already exists"))
  return "Bu e-poçtla artıq hesab var. Aşağıdakı «E-poçtla hesaba daxil ol» düyməsini istifadə et.";
 if(code==="weak_password"||message.includes("password"))
  return "Şifrə qəbul edilmədi. Daha güclü şifrə seç: ən azı 8 simvol, hərf və rəqəm.";
 if(code==="invalid_credentials"||message.includes("invalid login credentials"))
  return "Bu e-poçt və şifrə ilə giriş alınmadı. Hesabın yoxdursa, «Yeni hesab yarat» seç. Hesabın varsa, şifrəni yoxla və ya «Şifrəni unutmusunuz?» düyməsindən istifadə et. Google ilə açılmış hesab üçün Google girişini seç.";
 if(code==="email_not_confirmed"||message.includes("email not confirmed"))
  return "Bu hesabın e-poçtu hələ təsdiqlənməyib. Gmail-in Gələnlər və Spam qovluqlarını yoxla. «Təsdiq mesajını yenidən göndər» düyməsindən istifadə edə bilərsən.";
 if(code==="unexpected_failure"||message.includes("database error saving new user")||message.includes("database error"))
  return "Qeydiyyat serverdə saxlanmadı. İstifadəçi adı artıq götürülmüş ola bilər; başqa adla yoxla. Yenə alınmasa, sayt rəhbərliyi bazanı yoxlamalıdır.";
 if(code==="validation_failed"||message.includes("invalid"))
  return kind==="signup"?"Məlumatlardan biri server tərəfindən qəbul edilmədi. E-poçtu və istifadəçi adını yoxla. Problem davam edərsə, xətanı sayt rəhbərliyinə bildir.":"Giriş məlumatları qəbul edilmədi. E-poçt və şifrəni yoxla.";
 return "Əməliyyat alınmadı. Bir daha cəhd et. Problem davam edərsə, xəta kodu: "+(code||"naməlum")+".";
}
// Yalnız xəta kodu və HTTP statusu göstərilir; e-poçt, şifrə və token göstərilmir.
function authErrorCode(error){
 const code=String(error?.code||"unknown_error").replace(/[^a-zA-Z0-9_-]/g,"").slice(0,60);
 const status=Number(error?.status);
 return `Xəta kodu: ${code}${Number.isInteger(status)&&status>=400&&status<=599?` (HTTP ${status})`:""}.`;
}
// V68: Yalniz brauzer ucun aciq (public) Supabase Auth ayarlarini oxu.
// Bu, istifadecinin panelde deyisdirdiyi basqa layihe ile sayt layihəsini qarisdirmamasi ucundur.
async function readActualEmailAuthSettings(){
 const url=new URL("auth/v1/settings",cfg.supabaseUrl.replace(/\/?$/, "/"));
 const response=await fetch(url.toString(),{
  method:"GET",headers:{apikey:cfg.supabaseAnonKey},cache:"no-store"
 });
 if(!response.ok)throw new Error(`Auth settings HTTP ${response.status}`);
 const settings=await response.json();
 return {
  project:new URL(cfg.supabaseUrl).hostname.split(".")[0],
  emailEnabled:typeof settings?.external?.email==="boolean"?settings.external.email:null,
  signupEnabled:typeof settings?.disable_signup==="boolean"?!settings.disable_signup:null,
  confirmOff:typeof settings?.mailer_autoconfirm==="boolean"?settings.mailer_autoconfirm:null
 };
}
function describeActualSettings(s){
 if(!s)return "Server ayarlarını birbaşa oxumaq mümkün olmadı; səbəb hələ dəqiqləşməyib.";
 if(s.emailEnabled===false)return `Saytın qoşulduğu ${s.project} layihəsində Email provayderi söndürülüb (Disabled). Onu aktiv et.`;
 if(s.signupEnabled===false)return `Saytın qoşulduğu ${s.project} layihəsində yeni qeydiyyat qadağandır (Allow new users to sign up — OFF).`;
 if(s.confirmOff===false)return `Sayt ${s.project} layihəsinə qoşulub; Email təsdiqi ON-dur. Qeydiyyat zamanı Gmail-ə təsdiq məktubu göndərilməlidir.`;
 if(s.confirmOff===true)return `Sayt ${s.project} layihəsinə qoşulub; Confirm Email OFF-dur, buna görə qeydiyyat zamanı təsdiq məktubu göndərilmir.`;
 return `Sayt ${s.project} layihəsinə qoşulub, amma server bütün təsdiq ayarlarını bildirmədi.`;
}
async function finishEmailRegistration(){
 emailAuthNotice("Qeydiyyat tamamlandı. Hesabına daxil oldun.","success");
 toast("Qeydiyyat tamamlandı.");
 closeModal("authModal");
 await updateAccount();
 await loadAds();
}
function setEmailAuthBusy(busy){
 ["emailSignUp","emailSignIn","emailSignInAfterConfirm","confirmEmailCode","forgotAuthPassword","resendConfirmEmail","authSaveNewPassword","authModeSignUp","authModeSignIn"].forEach(id=>$(id).disabled=busy);
}
["authUsername","authEmail","authPassword","authConfirmCode"].forEach(id=>$(id).addEventListener("input",()=>emailAuthNotice("")));
$("authConfirmCode").addEventListener("input",e=>{
 const input=e.currentTarget;
 input.value=input.value.replace(/\D/g, "").slice(0,8);
});
$("authConfirmCode").addEventListener("keydown",e=>{if(e.key==="Enter")$("confirmEmailCode").click()});
$("emailSignUp").addEventListener("click",async()=>{
 if(!db){emailAuthNotice("Qeydiyyat xidməti qoşulmayıb. Sayt rəhbərliyi bağlantını yoxlamalıdır.");return}
 emailAuthNotice("");
 const f=authFieldsValid();if(!f)return;
 setEmailAuthBusy(true);
 try{
  // Qeydiyyatdan once faktiki Auth serverin aciq ayarlarini yoxla.
  // Panelde OFF gorsense de JS-in baglandigi layihədə ON ola biler.
  let actualSettings=null;
  try{actualSettings=await readActualEmailAuthSettings()}
  catch(settingsError){console.warn("Auth ayarlari oxunmadi:",settingsError?.message||"namelum")}
  if(actualSettings && (actualSettings.emailEnabled===false || actualSettings.signupEnabled===false)){
   emailAuthNotice(describeActualSettings(actualSettings));
   return;
  }
  // Lokal file:// ve Live Server URL-ləri Supabase redirect allowlist-ində olmaya bilər.
  const {data,error}=await db.auth.signUp({
   email:f.email,password:f.password,options:{data:{username:f.username}}
  });
  if(error){
   console.error("E-poctla qeydiyyat xetasi:",{code:error.code,status:error.status,message:error.message});
   emailAuthNotice(`${describeEmailAuthError(error)} ${authErrorCode(error)}`);
   return;
  }
  if(data?.session){
   await finishEmailRegistration();
   return;
  }
  // signUp ilk sorğuda xeta vermeyib, amma sessiya yaratmayib.
  // Eyni sifre ile derhal signIn etmeyin: invalid_credentials yalniz ikinci
  // sorğunun xetasidir ve ilkin qeydiyyatin sebebini gizledir.
  if(!actualSettings){
   try{actualSettings=await readActualEmailAuthSettings()}
   catch(settingsError){console.warn("Auth ayarlari oxunmadi:",settingsError?.message||"namelum")}
  }
  const details=describeActualSettings(actualSettings);
  const identityList=data?.user?.identities;
  if(Array.isArray(identityList) && identityList.length===0){
   emailAuthNotice(`${details} Bu e-poctla hesab artiq movcud ola biler. Eger evvel Google ile daxil olmusan, Google girisini sec. Yeni hesab yarandigi tesdiqlenmedi. Diaqnostika: signup_existing_identity_possible.`);
   return;
  }
  if(!data?.user){
   emailAuthNotice(`${details} Qeydiyyat cavabinda istifadeci de yoxdur. Diaqnostika: signup_no_user_no_session. Auth Logs yoxlanmalidir.`);
   return;
  }
  if(actualSettings?.confirmOff===false || actualSettings?.confirmOff===null){
   // E-poçt təsdiqi tələb olunanda sessiya yaranmır; serverin 6 və ya 8 rəqəmli kodu soruşulur.
   showEmailCodeForm(f.email);
   emailAuthNotice("Təsdiq kodu göndərildi.","success");
   return;
  }
  emailAuthNotice(`Qeydiyyat tamamlanmadı. ${authErrorCode({code:"signup_no_session"})}`);
 }catch(error){
  console.error("E-poçtla qeydiyyat bağlantı xətası:",{code:error?.code,status:error?.status,message:error?.message});
  emailAuthNotice(`Qeydiyyat zamanı texniki xəta yarandı. İnternet bağlantısını yoxla. ${authErrorCode(error)}`);
 }
 finally{setEmailAuthBusy(false)}
});
async function signInWithEnteredEmail(){
 if(!db){emailAuthNotice("Giriş xidməti qoşulmayıb. Sayt rəhbərliyi bağlantını yoxlamalıdır.");return}
 emailAuthNotice("");
 const email=validAuthEmail();if(!email)return;
 const password=$("authPassword").value;
 if(!password){emailAuthNotice("Qeydiyyatda istifadə etdiyin şifrəni daxil et.");$("authPassword").focus();return}
 setEmailAuthBusy(true);
 try{
  const {error}=await db.auth.signInWithPassword({email,password});
  if(error){
   console.error("E-poçtla giriş xətası:",{code:error.code,status:error.status,message:error.message});
   const code=String(error.code||"").toLowerCase();
   if(code==="email_not_confirmed"){
    showEmailCodeForm(email);
    emailAuthNotice("E-poçt təsdiqlənməyib. Gmail-dəki təsdiq kodunu daxil et.");
   }else emailAuthNotice(describeEmailAuthError(error,"signin"));
   return;
  }
  $("emailSignInAfterConfirm").hidden=true;
  toast("Hesaba daxil oldun.");closeModal("authModal");await updateAccount();await loadAds();
 }catch(error){console.error("E-poçtla giriş bağlantı xətası:",error);emailAuthNotice("Serverlə əlaqə qurulmadı. İnterneti yoxla və yenidən cəhd et.")}
 finally{setEmailAuthBusy(false)}
}
$("emailSignIn").addEventListener("click",signInWithEnteredEmail);
$("emailSignInAfterConfirm").addEventListener("click",signInWithEnteredEmail);
$("forgotAuthPassword").addEventListener("click",async()=>{
 if(!db){emailAuthNotice("Serverə qoşulmaq mümkün deyil.");return}
 const email=validAuthEmail();if(!email)return;
 setEmailAuthBusy(true);
 try{
  // Supabase Authentication > URL Configuration > Site URL işlək sayt olmalıdır.
  const {error}=await db.auth.resetPasswordForEmail(email);
  if(error){emailAuthNotice(describeEmailAuthError(error,"reset"));return}
  emailAuthNotice("Bu ünvanla hesab varsa, şifrə yeniləmə linki göndəriləcək. E-poçtunu və Spam qovluğunu yoxla. Link işləmirsə, saytın Supabase Site URL ayarı yoxlanmalıdır.","success");
 }catch(error){console.error("Şifrə bərpası xətası:",error);emailAuthNotice("Şifrə bərpası sorğusu göndərilmədi. İnternet bağlantını yoxla.")}
 finally{setEmailAuthBusy(false)}
});
$("confirmEmailCode").addEventListener("click",async()=>{
 if(!db){emailAuthNotice("Bağlantı yoxdur.");return}
 const email=cleanAuthEmail(),token=$("authConfirmCode").value.replace(/\D/g,"");
 if(!email){emailAuthNotice("E-poçt ünvanını daxil et.");return}
 if(!/^(?:\d{6}|\d{8})$/.test(token)){emailAuthNotice("6 və ya 8 rəqəmli kodu yaz.");$("authConfirmCode").focus();return}
 setEmailAuthBusy(true);
 try{
  const {data,error}=await db.auth.verifyOtp({email,token,type:"email"});
  if(error){
   console.error("E-poçt kodu təsdiqlənmədi:",{code:error.code,status:error.status});
   const code=String(error.code||"").toLowerCase();
   emailAuthNotice(`${code.includes("expired")||code.includes("invalid")?"Kod yanlışdır və ya vaxtı bitib.":"Təsdiqləmə alınmadı."} ${authErrorCode(error)}`);
   return;
  }
  $("authConfirmCode").value="";
  emailAuthNotice("Təsdiqləndi!","success");
  toast("Hesab təsdiqləndi!");
  if(data?.session){
   session=data.session;currentUser=data.user||data.session.user;
   closeModal("authModal");
   await updateAccount();await loadAds();
  }else{
   setEmailAuthMode("signin");
   emailAuthNotice("Təsdiqləndi. İndi daxil ol.","success");
  }
 }catch(error){console.error("Kodun təsdiqi alınmadı:",error);emailAuthNotice("Bağlantı xətası. Yenidən yoxla.")}
 finally{setEmailAuthBusy(false)}
});
$("resendConfirmEmail").addEventListener("click",async()=>{
 if(!db){emailAuthNotice("Serverə qoşulmaq mümkün deyil.");return}
 const email=validAuthEmail();if(!email)return;
 setEmailAuthBusy(true);
 try{
  const {error}=await db.auth.resend({type:"signup",email});
  if(error){
   console.error("Təsdiq mesajının yenidən göndərilməsi xətası:",{code:error.code,status:error.status,message:error.message});
   emailAuthNotice(`${describeEmailAuthError(error)} ${authErrorCode(error)}`);
   return;
  }
  showEmailCodeForm(email);
  emailAuthNotice("Yeni kod göndərildi.","success");
 }catch(error){
  console.error("Təsdiq mesajı xətası:",error);
  emailAuthNotice(`Mesaj göndərilmədi. İnternet bağlantısını yoxlayın. ${authErrorCode(error)}`);
 }
 finally{setEmailAuthBusy(false)}
});
$("authSaveNewPassword").addEventListener("click",async()=>{
 if(!db||!currentUser||!passwordRecoveryActive){emailAuthNotice("Şifrə bərpası linkini e-poçtundan aç.");return}
 const password=$("authPassword").value;
 if(password.length<8){emailAuthNotice("Yeni şifrə ən azı 8 simvol olmalıdır.");return}
 setEmailAuthBusy(true);
 try{
  const {error}=await db.auth.updateUser({password});
  if(error){emailAuthNotice(describeEmailAuthError(error,"reset"));return}
  passwordRecoveryActive=false;
  $("authPassword").value="";
  setEmailAuthMode("signin");
  emailAuthNotice("Şifrən dəyişdirildi. İndi yeni şifrə ilə daxil ola bilərsən.","success");
 }catch(error){console.error("Yeni şifrə xətası:",error);emailAuthNotice("Şifrə yenilənmədi. Yenidən cəhd et.")}
 finally{setEmailAuthBusy(false)}
});
window.BALAKEN_NATIVE_AUTH_CALLBACK=async (payload)=>{
 if(!db)return;
 try{
  if(payload?.error){emailAuthNotice("Google girişi alınmadı: "+String(payload.error),"error");showModal("authModal");return}
  if(payload?.access_token&&payload?.refresh_token){
   const {error}=await db.auth.setSession({access_token:payload.access_token,refresh_token:payload.refresh_token});
   if(error)throw error;
  }else if(payload?.code){
   const {error}=await db.auth.exchangeCodeForSession(payload.code);
   if(error)throw error;
  }else{throw new Error("Google təsdiq məlumatı alınmadı.")}
  closeModal("authModal");toast("Hesaba daxil oldun.");await updateAccount();await loadAds();
 }catch(err){emailAuthNotice("Google giriş xətası: "+String(err?.message||"naməlum"));showModal("authModal")}
};
window.BALAKEN_ANDROID_BACK=()=>{
 const open=[...document.querySelectorAll(".modal:not([hidden])")].at(-1);
 if(open){open.hidden=true;return true}
 return false;
};
$("googleLogin").addEventListener("click",async()=>{
 if(!db){toast("Google girişini aktivləşdirmək üçün js/config.js faylında Supabase publishable key çatışmır.");return}
 if(!["http:","https:"].includes(window.location.protocol)){
  emailAuthNotice("Google ilə giriş üçün saytı VS Code-da Open with Live Server ilə aç. index.html faylını iki dəfə klikləyərək açma.");
  return;
 }
 // Android-da Google girişini WebView daxilində açmaq qadağandır.
 // Supabase OAuth linkini Chrome kimi sistem brauzerində açır, sonra tətbiqə qayıdırıq.
 const androidApp=Boolean(window.BalakenAndroid?.openOAuth);
 const redirectTo=androidApp?"balakenelan://auth-callback":window.location.origin+window.location.pathname;
 const button=$("googleLogin");button.disabled=true;
 try{
  if(androidApp){
   const {data,error}=await db.auth.signInWithOAuth({provider:"google",options:{redirectTo,skipBrowserRedirect:true}});
   if(error)throw error;
   if(!data?.url)throw new Error("Google keçidi yaradılmadı.");
   window.BalakenAndroid.openOAuth(data.url);
  }else{
   const {error}=await db.auth.signInWithOAuth({provider:"google",options:{redirectTo}});
   if(error)emailAuthNotice("Google girişi başladılmadı: "+error.message);
  }
 }catch(error){
  emailAuthNotice("Google girişi alınmadı: "+String(error?.message||"İnterneti yoxla."));
 }finally{button.disabled=false}
});
$("signOut").addEventListener("click",async()=>{if(db){await db.auth.signOut();toast("Hesabdan çıxıldı.");await updateAccount()}});
$("searchBtn").addEventListener("click",renderAds);
["minPriceFilter","maxPriceFilter","sortFilter","jobTypeFilter"].forEach(id=>$(id).addEventListener("change",renderAds));
$("adCategory").addEventListener("change",()=>{updateJobForm();updateCarForm()});
// Grow text rows as the seller writes, without opening another panel.
function growAdTextarea(field){
 field.style.height="auto";
 field.style.height=Math.max(field.scrollHeight,field.rows*24+28)+"px";
}
$("adForm").querySelectorAll("textarea").forEach(field=>{
 field.addEventListener("input",()=>growAdTextarea(field));
});

["carBrand","carModel","carYear"].forEach(id=>$(id).addEventListener("input",updateCarTitle));
$("resetFilters").addEventListener("click",()=>{
  $("searchInput").value="";$("itemFilter").value="";$("saleBrandFilter").value="";$("saleModelFilter").value="";document.querySelectorAll("#rentalFilters input,#rentalFilters select").forEach(el=>el.value="");$("locationFilter").value="";updateLocationChildren("filter");$("categoryFilter").value="";
  $("minPriceFilter").value="";$("maxPriceFilter").value="";$("sortFilter").value="newest";
  chosenCategory="";document.querySelectorAll(".category").forEach(x=>x.classList.remove("active"));updateJobFilter();renderAds();
  setFiltersOpen(false);
});
$("searchInput").addEventListener("keydown",e=>{if(e.key==="Enter")renderAds()});
$("locationFilter").addEventListener("change",()=>{updateLocationChildren("filter");renderAds()});
$("locationChildFilter").addEventListener("change",()=>{updateLocationVillage("filter");renderAds()});
$("locationVillageFilter").addEventListener("change",()=>{locationAreaNote("filter");renderAds()});
$("adLocationChild").addEventListener("change",()=>updateLocationVillage("ad"));
$("adLocationVillage").addEventListener("change",()=>locationAreaNote("ad"));
$("adLocation").addEventListener("change",()=>updateLocationChildren("ad"));
$("categoryFilter").addEventListener("change",()=>{chosenCategory="";document.querySelectorAll(".category").forEach(x=>x.classList.remove("active"));updateJobFilter();renderAds()});
let selectedImages=[];
 function releaseImagePreview(item){
  if(item?.kind==="file" && item.previewUrl)URL.revokeObjectURL(item.previewUrl);
 }
 function renderImagePreviews(){
  const wrap=$("adImagePreview"),name=$("adImageName"),help=$("adImageHelp");
  if(!wrap||!name)return;
  wrap.innerHTML="";
  name.textContent=selectedImages.length?`${selectedImages.length} şəkil seçilib`:"Şəkil seçilməyib";
  if(help)help.textContent=selectedImages.length?"İlk şəkil əsas şəkildir. Şəkilləri sürüşdürərək sıranı dəyişə və ya “Əsas et” düyməsini basa bilərsən.":"";
  selectedImages.forEach((item,index)=>{
   const el=document.createElement("div");el.className="image-preview-item";el.draggable=true;el.dataset.imageIndex=String(index);
   const img=document.createElement("img");img.src=item.kind==="file"?item.previewUrl:item.url;img.alt=`Elan şəkli ${index+1}`;
   img.onerror=()=>{img.alt="Şəkil göstərilə bilmir";img.classList.add("image-preview-broken")};
   const badge=document.createElement("span");badge.className="image-preview-label";badge.textContent=index===0?"Əsas şəkil":`Şəkil ${index+1}`;
   const actions=document.createElement("div");actions.className="image-preview-actions";
   const orderControls=document.createElement("div");orderControls.className="image-order-controls";
   if(index>0){
    const left=document.createElement("button");left.type="button";left.className="image-action";left.textContent="←";left.title="Əvvələ çək";
    left.addEventListener("click",()=>moveImage(index,index-1));orderControls.append(left);
    const cover=document.createElement("button");cover.type="button";cover.className="image-action image-cover";cover.textContent="Əsas et";cover.title="Əsas şəkil et";
    cover.addEventListener("click",()=>moveImage(index,0));orderControls.append(cover);
   }
   if(index<selectedImages.length-1){
    const right=document.createElement("button");right.type="button";right.className="image-action";right.textContent="→";right.title="Sona çək";
    right.addEventListener("click",()=>moveImage(index,index+1));orderControls.append(right);
   }
   const remove=document.createElement("button");remove.type="button";remove.className="image-action image-remove";remove.textContent="×";remove.title="Şəkli sil";remove.setAttribute("aria-label",`Şəkil ${index+1} sil`);
   remove.addEventListener("click",()=>{const [removed]=selectedImages.splice(index,1);releaseImagePreview(removed);renderImagePreviews()});
   actions.append(orderControls,remove);el.append(img,badge,actions);
   el.addEventListener("dragstart",e=>{e.dataTransfer.setData("text/plain",String(index));e.dataTransfer.effectAllowed="move";el.classList.add("is-dragging")});
   el.addEventListener("dragend",()=>{el.classList.remove("is-dragging");wrap.querySelectorAll(".is-drop-target").forEach(n=>n.classList.remove("is-drop-target"))});
   el.addEventListener("dragover",e=>{e.preventDefault();e.dataTransfer.dropEffect="move";el.classList.add("is-drop-target")});
   el.addEventListener("dragleave",()=>el.classList.remove("is-drop-target"));
   el.addEventListener("drop",e=>{e.preventDefault();el.classList.remove("is-drop-target");const from=Number(e.dataTransfer.getData("text/plain"));if(Number.isInteger(from)&&from>=0&&from<selectedImages.length&&from!==index)moveImage(from,index)});
   wrap.append(el);
  });
 }
 function moveImage(from,to){
  if(from===to||from<0||to<0||from>=selectedImages.length||to>=selectedImages.length)return;
  const [item]=selectedImages.splice(from,1);selectedImages.splice(to,0,item);renderImagePreviews();
 }
 function addImageFiles(fileList){
  const incoming=Array.from(fileList||[]);
  const acceptedTypes=["image/jpeg","image/png","image/webp"];
  let rejectedType=0,rejectedSize=0,overflow=0;
  for(const file of incoming){
   if(!acceptedTypes.includes(file.type)){rejectedType++;continue}
   if(file.size>=5*1024*1024){rejectedSize++;continue}
   if(selectedImages.length>=10){overflow++;continue}
   selectedImages.push({kind:"file",file,previewUrl:URL.createObjectURL(file)});
  }
  const messages=[];
  if(rejectedType)messages.push(`${rejectedType} fayl qəbul edilmədi. JPG, PNG və ya WEBP seç.`);
  if(rejectedSize)messages.push(`${rejectedSize} şəkil 5 MB və ya daha böyükdür. Daha kiçik şəkil seç.`);
  if(overflow)messages.push("Bir elana maksimum 10 şəkil əlavə etmək olar.");
  if(messages.length)toast(messages.join(" "));
  $("adImage").value="";
  renderImagePreviews();
 }
 $("adImage").addEventListener("change",()=>addImageFiles($("adImage").files));
 const imageDropzone=$("adImageDropzone");
 if(imageDropzone){
  ["dragenter","dragover"].forEach(type=>imageDropzone.addEventListener(type,e=>{e.preventDefault();e.stopPropagation();imageDropzone.classList.add("is-dragover")}));
  ["dragleave","drop"].forEach(type=>imageDropzone.addEventListener(type,e=>{e.preventDefault();e.stopPropagation();imageDropzone.classList.remove("is-dragover")}));
  imageDropzone.addEventListener("drop",e=>{if(e.dataTransfer?.files?.length)addImageFiles(e.dataTransfer.files)});
 }
 function resetAdForm(){
  $("adLocation").value="";updateLocationChildren("ad");
  const form=$("adForm");if(form)form.reset();
  updateJobForm();updateCarForm();
  if($("adEditId"))$("adEditId").value="";
  if($("adExistingImage"))$("adExistingImage").value="";
  selectedImages.forEach(releaseImagePreview);selectedImages=[];
  if($("adImage"))$("adImage").value="";renderImagePreviews();
  if($("adSubmitButton")){$("adSubmitButton").textContent="Elanı yayımla";$("adSubmitButton").disabled=false}
  if($("adModalTitle"))$("adModalTitle").textContent="Elan yerləşdir";
 }
async function editAd(adId){
 let a=ads.find(item=>String(item.id)===String(adId));
 if(!a && db && currentUser){
  const result=await db.from("ads").select("*").eq("id",adId).eq("user_id",currentUser.id).maybeSingle();
  if(result.error){toast("Elan açılmadı: "+result.error.message);return}
  a=result.data;
 }
 if(!a || !currentUser || a.user_id!==currentUser.id){toast("Bu elanı redaktə etmək icazən yoxdur.");return}
 let savedMedia=[];
 if(db){
  const mediaResult=await db.from("ad_media").select("media_url,sort_order").eq("ad_id",a.id).eq("media_type","image").order("sort_order",{ascending:true});
  if(mediaResult.error){toast("Elan şəkilləri oxunmadı: "+mediaResult.error.message);return}
  savedMedia=(mediaResult.data||[]).map(m=>m.media_url);
 }
 selectedImages=[...new Set([a.image_url,...savedMedia].filter(Boolean))].map(url=>({kind:"url",url}));
 $("adEditId").value=String(a.id);
 $("adExistingImage").value=a.image_url||"";
 $("adModalTitle").textContent="Elanı redaktə et";
 $("adSubmitButton").textContent="Dəyişiklikləri saxla";
 $("adTitle").value=a.title||"";
 $("adPrice").value=a.price;
 $("adCategory").value=a.category;
 updateJobForm();updateCarForm();
 const rp=parseRental(a.description);for(const [key,id] of Object.entries(rentKeys))$(id).value=rp.rent[key]|| (key==="period"?"day":"");updateRentalForm();
 const cp=parseCarDescription(a.description);const car=cp.car||{};
 for(const [id,key] of [["carBrand","brand"],["carModel","model"],["carYear","year"],["carColor","color"],["carEngine","engine"],["carPower","power"],["carMileage","mileage"],["carGearbox","gearbox"]])$(id).value=car[key]||"";
 if(a.category===CAR_CATEGORY)updateCarTitle();
 const jobParsed=parseJobDescription(a.description);
 const job=jobParsed.job||{};
 $("jobType").value=job.type||"";
 $("jobWorkplace").value=job.workplace||"";
 $("jobSchedule").value=job.schedule||"";
 $("jobExperience").value=job.experience||"";
 $("jobEducation").value=job.education||"";
 $("jobRequirements").value=job.requirements||"";
 const area=resolveLocationSelection(a.location);$("adLocation").value=area.parent;updateLocationChildren("ad",area.child,area.village);
 $("adPhone").value=a.phone||"";
 $("adDescription").value=a.category===RENT_CATEGORY?rp.text:a.category===CAR_CATEGORY?cp.text:(jobParsed.text||"");
 $("adImage").value="";renderImagePreviews();
 showModal("adModal");
}
async function deleteAd(adId){
 if(!db || !currentUser){toast("Daxil olmaq lazımdır.");return}
 if(!confirm("Bu elanı silmək istədiyinə əminsən?"))return;
 const {data,error}=await db.from("ads").delete().eq("id",adId).eq("user_id",currentUser.id).select("id");
 if(error){toast("Elan silinmədi: "+error.message);return}
 if(!data?.length){toast("Elan tapılmadı və ya onu silmək icazən yoxdur.");return}
 toast("Elan silindi.");await loadAds();await loadMyAds();
}
async function renewAd(adId){
 if(!db || !currentUser){toast("Daxil olmaq lazımdır.");return}
 const {error}=await db.rpc("renew_my_ad",{ad_id:adId});
 if(error){toast("Elan yenilənmədi: "+error.message);return}
 toast("Elanın müddəti 2 ay uzadıldı.");await loadAds();await loadMyAds();
}
$("adForm").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!db||!currentUser){toast("Elan yerləşdirmək üçün əvvəlcə Google ilə daxil ol.");showModal("authModal");return}
  const editId=$("adEditId").value;
  const isJob=$("adCategory").value===JOB_CATEGORY;
  if(isJob&&!$("jobType").value){toast("İş elanının növünü seç.");return}
  const isCar=$("adCategory").value===CAR_CATEGORY;
  if(isCar&&(!$("carBrand").value||!$("carModel").value.trim()||!$("carYear").value)){toast("Marka, model və ili doldur.");return}
  if(isCar)updateCarTitle();
  const fullDescription=$("adCategory").value===RENT_CATEGORY?RENT_START+JSON.stringify(rentalData())+RENT_END+$("adDescription").value.trim():isJob?buildJobDescription():isCar?buildCarDescription():$("adDescription").value.trim();
  if(fullDescription.length>2000){toast("İş məlumatları və açıqlama birlikdə 2000 simvoldan çoxdur. Mətni qısalt.");return}
  if(selectedImages.length>10){toast("Bir elana maksimum 10 şəkil əlavə etmək olar.");return}
  for(const item of selectedImages){
   if(item.kind==="file"&&(!["image/jpeg","image/png","image/webp"].includes(item.file.type)||item.file.size>=5*1024*1024)){
    toast("Yalnız JPG, PNG və WEBP; hər şəkil 5 MB-dan kiçik olmalıdır.");return;
   }
  }
  const submitButton=$("adSubmitButton");
  submitButton.disabled=true;submitButton.textContent="Şəkillər yüklənir…";
  try{
   const finalImages=[];
   const newImageCount=selectedImages.filter(x=>x.kind==="file").length;
   let uploadedCount=0;
   for(const item of selectedImages){
    if(item.kind==="url"){finalImages.push(item.url);continue}
    const file=item.file;
    const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_").slice(-100)||"image";
    const path=`${currentUser.id}/${crypto.randomUUID()}-${safeName}`;
    const {error:upErr}=await db.storage.from("ad-images").upload(path,file,{upsert:false,contentType:file.type});
    if(upErr)throw new Error(`Şəkil yüklənmədi (${file.name}): ${upErr.message}`);
    const {data}=db.storage.from("ad-images").getPublicUrl(path);
    if(!data?.publicUrl)throw new Error(`Yüklənən şəklin ünvanı alınmadı: ${file.name}`);
    finalImages.push(data.publicUrl);uploadedCount++;
    submitButton.textContent=`Şəkillər yüklənir… ${uploadedCount}/${newImageCount}`;
   }
   const image_url=finalImages[0]||null;
   const savedProfile=await profile();
   const seller_name=(savedProfile?.username||currentUser.user_metadata?.full_name||currentUser.user_metadata?.name||currentUser.user_metadata?.username||currentUser.email?.split("@")[0]||"").trim()||"İstifadəçi";
   const payload={title:$("adTitle").value.trim(),price:isJob?0:Number($("adPrice").value),category:$("adCategory").value,location:storedLocation(),phone:$("adPhone").value.trim(),description:fullDescription,image_url,seller_name};
   submitButton.textContent="Elan yadda saxlanır…";
   let result,savedAdId=editId||null;
   if(editId){
    result=await db.from("ads").update({...payload,updated_at:new Date().toISOString()}).eq("id",editId).eq("user_id",currentUser.id).select("id").single();
    if(!result.error)savedAdId=result.data?.id||editId;
   }else{
    result=await db.from("ads").insert({...payload,user_id:currentUser.id,status:"published"}).select("id").single();
    if(!result.error)savedAdId=result.data?.id||null;
   }
   if(result.error)throw new Error((editId?"Dəyişikliklər saxlanmadı: ":"Elan əlavə olunmadı: ")+result.error.message);
   if(savedAdId){
    const {error:deleteMediaError}=await db.from("ad_media").delete().eq("ad_id",savedAdId).eq("media_type","image");
    if(deleteMediaError)throw new Error("Elan saxlanıldı, amma şəkil siyahısı yenilənmədi: "+deleteMediaError.message);
    if(finalImages.length){
     const {error:mediaError}=await db.from("ad_media").insert(finalImages.map((url,i)=>({ad_id:savedAdId,media_type:"image",media_url:url,sort_order:i})));
     if(mediaError)throw new Error("Elan saxlanıldı, amma şəkil siyahısı yazılmadı: "+mediaError.message);
    }
   }
   resetAdForm();closeModal("adModal");toast(editId?"Elan yeniləndi.":"Elan yayımlandı.");await loadAds();await loadMyAds();
  }catch(error){
   console.error("Elan/şəkil yükləmə xətası:",error);
   toast(error?.message||"Elan və ya şəkillər yadda saxlanmadı. İnterneti və Supabase Storage qaydalarını yoxla.");
  }finally{
   submitButton.disabled=false;
   if(submitButton.textContent.includes("yüklənir")||submitButton.textContent.includes("yadda saxlanır"))submitButton.textContent=editId?"Dəyişiklikləri saxla":"Elanı yayımla";
  }
 });
async function reportAd(adId){
 if(!db){toast("Şikayət sistemi üçün Supabase qoşulmalıdır.");return}
 if(!currentUser){showModal("authModal");toast("Şikayət etmək üçün daxil ol.");return}
 const reason=prompt("Şikayətin səbəbini yaz (məsələn: saxta elan, yanlış qiymət):");
 if(!reason||!reason.trim())return;
 const {error}=await db.from("reports").insert({ad_id:adId,reporter_id:currentUser.id,reason:reason.trim()});
 if(error)toast("Şikayət göndərilmədi: "+error.message);else toast("Şikayət adminə göndərildi. Təşəkkür edirik.");
}
async function loadReports(){
 if(!db)return;
 const {data,error}=await db.from("reports").select("id,reason,created_at,ad_id,ads(title,user_id,status)").eq("resolved",false).order("created_at",{ascending:false}).limit(100);
 if(error){$("reportsList").textContent="Şikayətlər yüklənmədi: "+error.message;return}
 $("reportsList").innerHTML="";
 if(!data?.length){$("reportsList").innerHTML='<div class="empty">Açıq şikayət yoxdur.</div>';return}
 data.forEach(r=>{const el=document.createElement("div");el.className="report-item";el.innerHTML=`<strong>${escapeHtml(r.ads?.title||"Silinmiş elan")}</strong><p>${escapeHtml(r.reason)}</p><small>${new Date(r.created_at).toLocaleString("az-AZ")}</small><br><button class="btn outline" data-hide-ad="${r.ad_id}" data-report-id="${r.id}">Elanı sil və şikayəti bağla</button><button class="btn outline" data-resolve="${r.id}">Yalnız şikayəti bağla</button>`;$("reportsList").append(el)});
 $("reportsList").querySelectorAll("[data-hide-ad]").forEach(b=>b.addEventListener("click",async()=>{const {error}=await db.from("ads").update({status:"removed"}).eq("id",b.dataset.hideAd);if(error)toast(error.message);else{await db.from("reports").update({resolved:true}).eq("id",b.dataset.reportId);toast("Elan silindi.");await loadAds();await loadMyAds();await loadReports()}}));
 $("reportsList").querySelectorAll("[data-resolve]").forEach(b=>b.addEventListener("click",async()=>{const {error}=await db.from("reports").update({resolved:true}).eq("id",b.dataset.resolve);if(error)toast(error.message);else{toast("Şikayət bağlandı.");await loadReports()}}));
}
$("refreshReports").addEventListener("click",loadReports);

function supportFailure(error){
 return ["42P01","PGRST205"].includes(error?.code)?"Kömək bölməsi hələ aktivləşdirilməyib. Bir az sonra yenidən yoxla.":"Müraciət göndərilmədi. İnterneti yoxla və yenidən cəhd et.";
}
async function loadMySupport(){
 const list=$("mySupportList");list.replaceChildren();
 if(!db||!currentUser){list.textContent="Müraciət göndərmək və izləmək üçün hesabına daxil ol.";return}
 const {data,error}=await db.from("support_requests").select("id,topic,message,status,created_at").eq("user_id",currentUser.id).order("created_at",{ascending:false}).limit(20);
 if(error){list.textContent="Müraciətlər hazırda yüklənmir.";return}
 if(!data.length){list.textContent="Hələ müraciətin yoxdur.";return}
 data.forEach(r=>{const el=document.createElement("article");el.className="report-item";el.innerHTML=`<strong>${escapeHtml(r.topic)}</strong><p class="support-message">${escapeHtml(r.message)}</p><small>${r.status==="resolved"?"Həll edildi":"Baxılır"} · ${new Date(r.created_at).toLocaleString("az-AZ")}</small>`;list.append(el)});
}
$("supportOpen").addEventListener("click",()=>{showModal("supportModal");$("supportNotice").textContent=currentUser?"":"Göndərmək üçün əvvəl hesabına daxil ol. Yazdığın mətn burada qalacaq.";loadMySupport()});
$("supportForm").addEventListener("submit",async event=>{
 event.preventDefault();const notice=$("supportNotice"),button=$("supportSubmit");
 if(!db){notice.textContent="Serverlə əlaqə yoxdur. Bir az sonra yenidən yoxla.";return}
 if(!currentUser){notice.textContent="Əvvəl hesabına daxil ol, sonra bu bölmədən müraciətini göndər.";closeModal("supportModal");showModal("authModal");return}
 const message=$("supportMessage").value.trim();if(message.length<10){notice.textContent="Problemi ən azı 10 simvolla izah et.";return}
 button.disabled=true;notice.textContent="Göndərilir…";
 try{
  const {error}=await db.from("support_requests").insert({user_id:currentUser.id,topic:$("supportTopic").value,message,contact:$("supportContact").value.trim()});
  if(error){notice.textContent=supportFailure(error);return}
  $("supportForm").reset();notice.textContent="Müraciətin göndərildi. Sayt rəhbərliyi problemini görəcək.";await loadMySupport();
 }catch{notice.textContent="Əlaqə qurulmadı. Yazdıqların saxlanılıb, yenidən göndərə bilərsən."}
 finally{button.disabled=false}
});
async function loadSupportAdmin(){
 const list=$("supportAdminList");list.replaceChildren();
 if(!db||$("adminPanel").dataset.staff!=="yes")return;
 const {data,error}=await db.from("support_requests").select("id,topic,message,contact,status,created_at,user_id").order("created_at",{ascending:false}).limit(100);
 if(error){list.textContent="Müraciətlər yüklənmədi. Dəstək bölməsinin SQL faylının işlədildiyini yoxla.";return}
 if(!data.length){list.textContent="Müraciət yoxdur.";return}
 data.forEach(r=>{
  const el=document.createElement("article");el.className="report-item";
  el.innerHTML=`<strong>${escapeHtml(r.topic)}</strong><p class="support-message">${escapeHtml(r.message)}</p><p>Əlaqə: ${escapeHtml(r.contact||"Göstərilməyib")}</p><small>${new Date(r.created_at).toLocaleString("az-AZ")} · ${r.status==="resolved"?"Həll edildi":"Açıq"}</small>`;
  if(r.status!=="resolved"){
   const b=document.createElement("button");b.type="button";b.className="btn outline";b.textContent="Həll edildi";
   b.addEventListener("click",async()=>{b.disabled=true;try{const {data:rows,error}=await db.from("support_requests").update({status:"resolved"}).eq("id",r.id).select("id");if(error||!rows?.length){toast("Müraciət yenilənmədi.");b.disabled=false;return}await loadSupportAdmin()}catch{toast("Əlaqə qurulmadı.");b.disabled=false}});el.append(document.createElement("br"),b);
  }
  list.append(el);
 });
}
$("refreshSupport").addEventListener("click",loadSupportAdmin);

$("refreshMyAds").addEventListener("click",loadMyAds);

let adminAdRows=[],adminAdOffset=0;
const canAdmin=()=>Boolean(db&&currentUser&&$("adminPanel").dataset.staff==="yes");
function safeHttps(value){try{const u=new URL(value);return u.protocol==="https:"&&!u.username&&!u.password?u.href:null}catch{return null}}
function renderAdminAds(){
 const q=searchText($("adminAdSearch").value),list=$("adminAdsList");list.replaceChildren();
 const status=$("adminStatusFilter").value;
 const rows=adminAdRows.filter(a=>(!q||searchText([a.title,a.phone,a.location].join(" ")).includes(q))&&(!status||(status==="spam"?a.admin_reason==="spam":a.status===status)));
 $("adminAdCount").textContent=`Yüklənən elan: ${adminAdRows.length} · Seçimə uyğun: ${rows.length}`;
 if(!rows.length){list.textContent="Uyğun elan yoxdur.";return}
 rows.forEach(a=>{
  const el=document.createElement("article");el.className="report-item";
  el.innerHTML=`<strong>${escapeHtml(a.title)}</strong><p>${escapeHtml(a.location||"")} · ${escapeHtml(a.phone||"")}</p><small>${a.admin_reason==="spam"?"Spam":escapeHtml(a.status)} · ${new Date(a.created_at).toLocaleString("az-AZ")}</small>`;
  const actions=document.createElement("div");actions.className="product-actions";
  [["Spam kimi gizlət","spam"],["Elanı sil","remove"],["Yenidən göstər","restore"]].forEach(([label,action])=>{
   const b=document.createElement("button");b.type="button";b.className="btn outline";b.textContent=label;
   b.addEventListener("click",async()=>{
    if(!canAdmin())return;
    if(action!=="restore"&&!confirm(label+"? Elan ümumi lentdən çıxarılacaq."))return;
    b.disabled=true;
    try{
     const patch={status:action==="restore"?"published":"removed",admin_reason:action==="spam"?"spam":action==="remove"?"removed":null};
     const {data:updated,error}=await db.from("ads").update(patch).eq("id",a.id).select("id");
     if(error||!updated?.length){toast("Elan yenilənmədi. Admin SQL ayarını yoxla.");return}
     toast(action==="restore"?"Elan yenidən aktivləşdirildi.":"Elan lentdən çıxarıldı.");await loadAdminAds(true);await loadAds();await loadMyAds();
    }catch{toast("Serverlə əlaqə qurulmadı.")}finally{b.disabled=false}
   });actions.append(b);
  });el.append(actions);list.append(el);
 });
}
async function loadAdminAds(reset=false){
 if(!canAdmin())return;
 if(reset){adminAdRows=[];adminAdOffset=0}
 const {data,error}=await db.from("ads").select("id,title,phone,location,status,admin_reason,created_at").order("created_at",{ascending:false}).order("id").range(adminAdOffset,adminAdOffset+99);
 if(error){$("adminAdsList").textContent="Elanlar yüklənmədi. Admin idarəetmə SQL faylını işlət.";return}
 adminAdRows.push(...data);adminAdOffset+=data.length;$("adminAdsMore").hidden=data.length<100;renderAdminAds();
}
$("refreshAdminAds").addEventListener("click",()=>loadAdminAds(true));
$("adminAdsMore").addEventListener("click",()=>loadAdminAds());
$("adminAdSearch").addEventListener("input",renderAdminAds);
$("adminStatusFilter").addEventListener("change",renderAdminAds);
let adminUsers=[],adminUsersPage=1,adminUsersBusy=false;
async function adminUserRequest(body){
 const {data,error}=await db.functions.invoke("admin-users",{body});
 if(error){
  let message="İstifadəçi idarəetməsi açılmadı. Serverdə admin-users funksiyası və user-management.sql quraşdırılmalıdır.";
  try{const result=await error.context.json();if(result.error)message=result.error}catch{}
  throw new Error(message);
 }
 if(data?.error)throw new Error(data.error);
 if(!data)throw new Error("Server cavabı alınmadı.");
 return data;
}
function renderAdminUsers(){
 const list=$("adminUsersList");list.replaceChildren();
 const q=searchText($("adminUserSearch").value);
 const rows=adminUsers.filter(u=>!q||searchText(u.name+" "+u.email).includes(q));
 if(!rows.length){list.textContent="Bu səhifədə uyğun istifadəçi yoxdur.";return}
 for(const user of rows){
  const item=document.createElement("article");item.className="report-item";
  const title=document.createElement("strong");title.textContent=user.email||user.id;
  const info=document.createElement("p");info.textContent=(user.name?user.name+" · ":"")+(user.self?"Sayt rəhbəri":user.blocked?"Bloklanıb":"Aktiv");
  item.append(title,info);
  if(!user.self){
   const actions=document.createElement("div");actions.className="product-actions";
   for(const [label,action] of [[user.blocked?"Bloku aç":"Blokla",user.blocked?"unblock":"block"],["Hesabı sil","delete"]]){
    const b=document.createElement("button");b.type="button";b.className="btn outline";b.textContent=label;
    b.addEventListener("click",async()=>{
     if(!canAdmin()||adminUsersBusy)return;
     const body={action,user_id:user.id};
     if(action==="delete"){
      const confirmation=prompt("DİQQƏT: Hesab, ona bağlı elanlar və şəkillər həmişəlik silinəcək. Geri qaytarılmır. Təsdiq üçün e-poçtu yaz: "+user.email);
      if(confirmation===null)return;
      if(confirmation!==user.email){toast("E-poçt uyğun gəlmir. Hesab silinmədi.");return}
      body.confirmation=confirmation;
     }else if(action==="block"){
      const reason=prompt("Bloklama səbəbini yaz:");if(reason===null)return;
      if(!reason.trim()){toast("Bloklama səbəbini yaz.");return}body.reason=reason.trim();
     }else if(!confirm(user.email+" hesabının bloku açılsın?"))return;
     adminUsersBusy=true;actions.querySelectorAll("button").forEach(x=>x.disabled=true);
     try{
      await adminUserRequest(body);
      toast(action==="delete"?"Hesab silindi.":action==="block"?"Hesab bloklandı.":"Blok açıldı.");
     }catch(error){$("adminUsersNotice").textContent=error.message;toast(error.message)}
     finally{adminUsersBusy=false;await loadAdminUsers(adminUsersPage,false);}
    });actions.append(b);
   }item.append(actions);
  }list.append(item);
 }
}
async function loadAdminUsers(page=1,clearNotice=true){
 if(!canAdmin()||adminUsersBusy)return;
 const uid=currentUser.id;
 adminUsersBusy=true;if(clearNotice)$("adminUsersNotice").textContent="İstifadəçilər yüklənir…";
 $("adminUsersPrev").disabled=true;$("adminUsersNext").disabled=true;
 try{
  const result=await adminUserRequest({action:"list",page});
  if(currentUser?.id!==uid||!canAdmin())return;
  adminUsers=result.users;adminUsersPage=page;
  if(clearNotice)$("adminUsersNotice").textContent="";
  $("adminUsersPage").textContent="Səhifə "+page;
  $("adminUsersPrev").disabled=page<=1;$("adminUsersNext").disabled=!result.more;
  renderAdminUsers();
 }catch(error){adminUsers=[];$("adminUsersList").replaceChildren();$("adminUsersNotice").textContent=error.message;}
 finally{adminUsersBusy=false;}
}
$("refreshAdminUsers").addEventListener("click",()=>loadAdminUsers(adminUsersPage));
$("adminUsersPrev").addEventListener("click",()=>loadAdminUsers(adminUsersPage-1));
$("adminUsersNext").addEventListener("click",()=>loadAdminUsers(adminUsersPage+1));
$("adminUserSearch").addEventListener("input",renderAdminUsers);
async function loadSiteBanners(){
 if(!db)return;
 const {data,error}=await db.from("site_banners").select("title,image_url,target_url").eq("active",true).order("created_at",{ascending:false}).limit(5);
 const list=$("siteBanners");list.replaceChildren();if(error)return;
 (data||[]).forEach(r=>{
  const image=safeHttps(r.image_url),target=safeHttps(r.target_url);if(!image||!target)return;
  const article=document.createElement("article"),tag=document.createElement("small"),a=document.createElement("a"),img=document.createElement("img");
  tag.textContent="Reklam";a.href=target;a.target="_blank";a.rel="noopener noreferrer sponsored";img.src=image;img.alt=r.title;img.loading="lazy";a.append(img);article.append(tag,a);list.append(article);
 });
}
async function loadAdminBanners(){
 if(!canAdmin())return;
 const list=$("adminBannersList");list.replaceChildren();
 const {data,error}=await db.from("site_banners").select("id,title,active").order("created_at",{ascending:false});
 if(error){list.textContent="Reklam bölməsinin SQL faylını işlət.";return}
 if(!data.length){list.textContent="Reklam yoxdur.";return}
 data.forEach(r=>{
  const el=document.createElement("article");el.className="report-item";const title=document.createElement("strong");title.textContent=r.title+(r.active?" · Aktiv":" · Bağlı");el.append(title,document.createElement("br"));
  [[r.active?"Dayandır":"Aktivləşdir","toggle"],["Sil","delete"]].forEach(([label,action])=>{
   const b=document.createElement("button");b.type="button";b.className="btn outline";b.textContent=label;
   b.addEventListener("click",async()=>{
    if(!canAdmin()||(action==="delete"&&!confirm("Reklam silinsin?")))return;
    b.disabled=true;try{
     const query=action==="delete"?db.from("site_banners").delete():db.from("site_banners").update({active:!r.active});
     const {data:rows,error}=await query.eq("id",r.id).select("id");
     if(error||!rows?.length){toast("Reklam yenilənmədi.");return}await loadAdminBanners();await loadSiteBanners();
    }catch{toast("Serverlə əlaqə qurulmadı.")}finally{b.disabled=false}
   });el.append(b);
  });list.append(el);
 });
}
$("bannerForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!canAdmin())return;const notice=$("bannerNotice"),b=$("bannerSave");
 const image=safeHttps($("bannerImage").value),target=safeHttps($("bannerLink").value);
 if(!image||!target){notice.textContent="Şəkil və keçid üçün https:// ilə başlayan link yaz.";return}
 b.disabled=true;try{
  const {error}=await db.from("site_banners").insert({title:$("bannerTitle").value.trim(),image_url:image,target_url:target,active:true});
  if(error){notice.textContent="Reklam əlavə edilmədi. SQL ayarını yoxla.";return}
  $("bannerForm").reset();notice.textContent="Reklam əlavə edildi.";await loadAdminBanners();await loadSiteBanners();
 }catch{notice.textContent="Serverlə əlaqə qurulmadı."}finally{b.disabled=false}
});

const filtersPanel=$("filtersPanel");
const toggleFiltersBtn=$("toggleFilters");
function setFiltersOpen(open){
 if(!filtersPanel||!toggleFiltersBtn)return;
 const state=Boolean(open);
 filtersPanel.hidden=!state;
 toggleFiltersBtn.setAttribute("aria-expanded",String(state));
 toggleFiltersBtn.textContent=state?"✖ Filtrləri bağla":"⚙️ Filtrlər";
}
if(toggleFiltersBtn){
 toggleFiltersBtn.addEventListener("click",()=>setFiltersOpen(filtersPanel.hidden));
}

function updateSaleCarFilter(){
 const category=$("categoryFilter").value||chosenCategory;
 const active=category===CAR_CATEGORY;
 const named=Boolean(category)&&!active;
 $("itemFilterWrap").hidden=!named;
 const labels={"Heyvanlar":["Heyvanın adı","Məsələn: inək, qoyun, toyuq"],"İş elanları":["İşin adı","Məsələn: elektrikçi, sürücü"],"Xidmətlər":["Xidmətin adı","Məsələn: kombi təmiri"],"Ev və torpaq":["Əmlakın adı","Məsələn: mənzil, həyət evi, torpaq"],"Kirayə":["Kirayə verilənin adı","Məsələn: ev, avtomobil, alət"]};
 const [label,hint]=labels[category]||["Əşyanın adı","Məsələn: telefon, soyuducu, divan"];
 $("itemFilterLabel").textContent=label;$("itemFilter").placeholder=hint;
 if(!named)$("itemFilter").value="";
 $("saleCarFilters").hidden=!active;
 if(!active){$("saleBrandFilter").value="";$("saleModelFilter").value="";}
}

function saleCarMatches(a){if(($("categoryFilter").value||chosenCategory)!==CAR_CATEGORY)return true;const c=parseCarDescription(a.description).car||{};return [["saleBrandFilter","brand"],["saleModelFilter","model"]].every(([id,key])=>!$(id).value||fuzzyTextMatch($(id).value,[c[key],a.title]));}
["itemFilter","saleBrandFilter","saleModelFilter"].forEach(id=>$(id).addEventListener("input",renderAds));

fillLocationParents($("locationFilter"),"Bütün Balakən");fillLocationParents($("adLocation"),"Ərazi seç");updateLocationChildren("filter");updateLocationChildren("ad");fillCategories();updateJobFilter();updateJobForm();updateCarForm();setFiltersOpen(false);
// Reset browser-restored filter values on every page entry, including back/forward cache.
window.addEventListener("pageshow",event=>{
 $("resetFilters").click();
 setAccountView(false);
 document.querySelectorAll(".inline-location-options").forEach(el=>el.hidden=true);
 document.querySelectorAll(".inline-location-trigger").forEach(el=>el.setAttribute("aria-expanded","false"));
 if(event.persisted){
  document.querySelectorAll(".modal").forEach(el=>el.hidden=true);
  window.scrollTo(0,0);
 }
});
configNotice();
showOAuthCallbackError();
if(db){refreshSession().then(loadAds)}else{loadAds()}
$("rentType").addEventListener("change",()=>{updateRentalForm();syncAdCategoryLayout()});
$("rentPeriod").addEventListener("change",syncAdCategoryLayout);
["rentFilterType","rentFilterPeriod","rentFilterBrand","rentFilterModel","rentFilterRooms"].forEach(id=>$(id).addEventListener("input",()=>{updateJobFilter();renderAds()}));



})();
