// Expand villages immediately below their own area, inside the same list.
(() => {
 const tree=window.BALAKEN_LOCATION_TREE||[];
 ['ad','filter'].forEach(kind=>{
  const filter=kind==='filter';
  const parent=document.getElementById(filter?'locationFilter':'adLocation');
  const child=document.getElementById(filter?'locationChildFilter':'adLocationChild');
  const village=document.getElementById(filter?'locationVillageFilter':'adLocationVillage');
  if(!parent||!child||!village)return;
  const required=parent.required;parent.required=false;parent.hidden=true;
  const box=document.createElement('div');box.className='inline-location-picker';
  const trigger=document.createElement('button');trigger.type='button';trigger.className='inline-location-trigger';trigger.id=parent.id+'Trigger';
  const list=document.createElement('div');list.className='inline-location-options location-tree';list.id=parent.id+'Options';list.hidden=true;
  const dropdown=document.createElement('div');dropdown.className='location-dropdown';dropdown.hidden=true;
  const search=document.createElement('input');search.type='search';search.placeholder='Ərazi axtar';search.setAttribute('aria-label','Kənd axtar');
  const searchWrap=document.createElement('div');searchWrap.className='location-search-entry';
  const searchIcon=document.createElement('span');searchIcon.textContent='🔍';searchIcon.setAttribute('aria-hidden','true');
  searchWrap.append(searchIcon,search);dropdown.append(searchWrap,list);list.hidden=false;
  const directNames=['Murğuztala','Roçəhməd','Qaracabinə','Qasbinə','Bedağar'];
  const normalize=t=>t.toLocaleLowerCase('az').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ı/g,'i').replace(/ə/g,'e');
  const places=[{name:'Qabaqçöl',area:'Qabaqçöl',place:'Qabaqçöl',leaf:''},...tree.flatMap(r=>r.subareas?r.subareas.flatMap(sub=>sub.places.map(name=>({name,area:r.label,place:sub.label,leaf:name}))):r.places.map(name=>({name,area:r.label,place:name,leaf:''})))];
  function choosePlace(item){choose(item.area,item.place,item.leaf);search.value='';dropdown.hidden=true;trigger.setAttribute('aria-expanded','false');render();trigger.focus()}
  search.className='location-quick-search';search.id=parent.id+'Search';
  search.addEventListener('input',()=>{dropdown.hidden=false;list.hidden=false;trigger.setAttribute('aria-expanded','true');render()});
  search.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();list.querySelector('button')?.focus()}});
  trigger.setAttribute('aria-controls',list.id);trigger.setAttribute('aria-expanded','false');
  parent.after(box);box.append(trigger,dropdown);
  const label=document.querySelector('label[for="'+parent.id+'"]');if(label)label.htmlFor=trigger.id;
  let expanded='',expandedSub='';
  const change=select=>select.dispatchEvent(new Event('change',{bubbles:true}));
  function choose(area,place='',leaf=''){
   parent.value=area;change(parent);
   child.value=place;change(child);
   village.value=leaf;change(village);
  }
  function button(text,selected,action,expand){
   const b=document.createElement('button');b.type='button';b.className='inline-location-option';b.textContent=text;
   b.setAttribute('aria-pressed',String(selected));if(expand!==undefined)b.setAttribute('aria-expanded',String(expand));
   b.addEventListener('click',action);return b;
  }
  function render(){
   const area=parent.value,place=child.value,leaf=village.value;
   const region=tree.find(r=>r.label===area);
   const standalone=directNames.find(name=>name===(leaf||place||area));
   const path=standalone?[standalone]:[region?.type==='Şəhər'?'Balakən şəhəri':area,place!==area?place:'',leaf].filter(Boolean);
   trigger.textContent=(path.join(' › ')||(filter?'Bütün Balakən':'Ərazi seç'))+' ▾';
   list.replaceChildren();
   if(search.value.trim()){
    const matches=places.filter(p=>normalize(p.name).includes(normalize(search.value.trim())));
    matches.forEach(p=>list.append(button(p.name,area===p.area&&place===p.place&&leaf===p.leaf,()=>choosePlace(p))));
    if(!matches.length){const empty=document.createElement('p');empty.className='location-empty';empty.textContent='Uyğun yer tapılmadı';list.append(empty)}
    return;
   }
   list.append(button(filter?'Bütün Balakən':'Seçimi təmizlə',!area,()=>{choose('');expanded='';expandedSub='';render()}));
   tree.filter(r=>!directNames.includes(r.label)).forEach(r=>{
    const open=expanded===r.label;
    const title=r.type==='Şəhər'?'Balakən şəhəri':r.label+' ərazi dairəsi';
    list.append(button(title+(r.type==='Şəhər'?'':open?' ▴':' ▾'),area===r.label,()=>{
     expanded=open?'':r.label;expandedSub='';
     choose(r.label,r.type==='Şəhər'?r.places[0]:'');render();
    },r.type==='Şəhər'?undefined:open));
    if(!open||r.type==='Şəhər')return;
    const group=document.createElement('div');group.className='location-tree-children';
    if(r.subareas){
     group.append(button('Qabaqçöl qəsəbəsi',place==='Qabaqçöl',()=>{choose(r.label,'Qabaqçöl');render()}));
     r.subareas.forEach(sub=>{
      const subOpen=expandedSub===sub.label;
      group.append(button(sub.label+' ərazi dairəsi'+(subOpen?' ▴':' ▾'),place===sub.label,()=>{
       expandedSub=subOpen?'':sub.label;choose(r.label,sub.label);render();
      },subOpen));
      if(subOpen){
       const leaves=document.createElement('div');leaves.className='location-tree-children';
       sub.places.filter(v=>!directNames.includes(v)).forEach(v=>leaves.append(button(v+' kəndi',leaf===v,()=>{choose(r.label,sub.label,v);render()})));
       group.append(leaves);
      }
     });
    }else r.places.filter(v=>!directNames.includes(v)).forEach(v=>group.append(button(v+' kəndi',place===v,()=>{choose(r.label,v);render()})));
    list.append(group);
   });
   directNames.forEach(name=>{const item=places.find(p=>p.name===name)||tree.filter(r=>r.label===name).map(r=>({name,area:r.label,place:r.places[0]||'',leaf:''}))[0];if(item)list.append(button(name,area===item.area&&place===item.place&&leaf===item.leaf,()=>choosePlace(item)))});
  }
  trigger.addEventListener('click',()=>{
   dropdown.hidden=!dropdown.hidden;trigger.setAttribute('aria-expanded',String(!dropdown.hidden));
   if(!dropdown.hidden){list.hidden=false;search.value='';expanded=parent.value;expandedSub=child.value;render()}
  });
  box.addEventListener('keydown',e=>{if(e.key==='Escape'){dropdown.hidden=true;trigger.setAttribute('aria-expanded','false');trigger.focus()}});
  const refresh=()=>{expanded=parent.value;expandedSub=child.value;render()};
  if(filter)document.getElementById('resetFilters')?.addEventListener('click',refresh);
  else{
   const form=document.getElementById('adForm');
   form.addEventListener('reset',()=>setTimeout(refresh,0));
   new MutationObserver(refresh).observe(document.getElementById('adModal'),{attributes:true,attributeFilter:['hidden']});
   if(required)form.addEventListener('submit',e=>{if(!parent.value){e.preventDefault();e.stopImmediatePropagation();dropdown.hidden=false;trigger.setAttribute('aria-expanded','true');trigger.focus()}},true);
  }
  render();
 });
})();
