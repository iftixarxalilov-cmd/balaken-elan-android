(() => {
 const size=24;
 window.BalakenPagination={
 slice(items,page){page=Math.max(1,Math.min(Number(page)||1,Math.max(1,Math.ceil(items.length/size))));return {page,items:items.slice((page-1)*size,page*size)}},
 render(nav,total,page,onChange){nav.replaceChildren();const pages=Math.ceil(total/size);nav.hidden=pages<=1;if(pages<=1)return;
 const add=(label,target,disabled=false,current=false)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.disabled=disabled;if(current)b.setAttribute('aria-current','page');b.addEventListener('click',()=>onChange(target));nav.append(b)};
 add('‹ Geri',page-1,page===1);let prev=0;
 for(const n of [...new Set([1,page-1,page,page+1,pages])].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b)){if(n-prev>1){const gap=document.createElement('span');gap.textContent='…';nav.append(gap)}add(String(n),n,false,n===page);prev=n}
 add('İrəli ›',page+1,page===pages);
 }
 };
})();