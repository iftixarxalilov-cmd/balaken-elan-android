(() => {
  const $ = id => document.getElementById(id);
  const cfg = window.BALAKEN_CONFIG || {};
  const params = new URLSearchParams(location.search);
  const sellerId = params.get('seller') || '';
  const sellerName = (params.get('name') || params.get('sellerName') || '').trim();
  const fromAd = params.get('fromAd') || '';
  const returnUrl = fromAd ? `index.html?ad=${encodeURIComponent(fromAd)}` : 'index.html';
  const configured = cfg.supabaseUrl && cfg.supabaseAnonKey && !cfg.supabaseUrl.includes('BURAYA') && !cfg.supabaseAnonKey.includes('BURAYA');
  const db = configured && window.supabase?.createClient ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey) : null;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const normalized = value => String(value || '').trim().toLocaleLowerCase('az');

  const backButton = $('sellerBackButton');
  if (backButton) backButton.addEventListener('click', () => {
    location.href = returnUrl;
  });

  async function loadSellerAds() {
    $('sellerPageTitle').textContent = sellerName ? `${sellerName} — bütün elanlar` : 'Elan sahibinin bütün elanları';
    if (!db) {
      $('sellerPageMessage').textContent = 'Elanları göstərmək üçün Supabase bağlantısı qurulmalıdır.';
      return;
    }
    if (!sellerId && !sellerName) {
      $('sellerPageMessage').textContent = 'Elan sahibinin məlumatı tapılmadı. Elan səhifəsindən bu düyməni yenidən aç.';
      return;
    }
    const activeQuery = () => db.from('ads').select('*')
      .in('status', ['published', 'active'])
      .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
      .order('created_at', { ascending: false }).limit(1000);
    let data = null;
    let error = null;
    // First query by the seller's permanent account ID; this is more reliable than the display name.
    if (sellerId) {
      const result = await activeQuery().eq('user_id', sellerId);
      data = result.data;
      error = result.error;
    }
    // Never mix another account's ads into an ID-based seller page.
    // Only legacy links without an account ID may use an exact display-name lookup.
    if (!sellerId && sellerName) {
      const result = await activeQuery().eq('seller_name', sellerName);
      data = result.data;
      error = result.error;
    }
    if (error) {
      console.error('Satıcının elanları yüklənmədi:', error);
      $('sellerPageMessage').textContent = 'Elanlar yüklənmədi: ' + error.message;
      return;
    }
    let items = (data || []).filter(ad => {
      const idMatch = sellerId && ad.user_id && String(ad.user_id) === sellerId;
      const nameMatch = !sellerId && sellerName && normalized(ad.seller_name) === normalized(sellerName);
      return Boolean(idMatch || nameMatch);
    });
    if (!items.length) {
      $('sellerPageMessage').textContent = 'Bu hesabın aktiv elanları tapılmadı. Elanların statusunu və müddətini yoxla.';
      $('sellerResultsCount').textContent = '0 elan';
      return;
    }
    const ids = items.map(ad => ad.id).filter(Boolean);
    const { data: media, error: mediaError } = await db.from('ad_media').select('ad_id,media_url,sort_order').eq('media_type','image').in('ad_id', ids).order('sort_order', { ascending: true });
    if (mediaError) console.warn('Əlavə şəkillər oxunmadı:', mediaError.message);
    const grouped = {};
    (media || []).forEach(row => { (grouped[row.ad_id] ||= []).push(row.media_url); });
    items = items.map(ad => ({ ...ad, images: [...new Set([ad.image_url, ...(grouped[ad.id] || [])].filter(Boolean))] }));
    $('sellerResultsCount').textContent = `${items.length} elan`;
    $('sellerPageMessage').textContent = items.length === 1 ? 'Bu istifadəçinin 1 aktiv elanı var.' : `Bu istifadəçinin ${items.length} aktiv elanı var.`;
    function renderSeller(page=1){
const selected=window.BalakenPagination.slice(items,page);
window.BalakenPagination.render($('sellerPagination'),items.length,selected.page,next=>{renderSeller(next);$('sellerPageTitle').scrollIntoView()});
$('sellerProducts').innerHTML = selected.items.map(ad => {
      const image = ad.images[0];
      const picture = image ? `<img src="${esc(image)}" alt="${esc(ad.title)}" loading="lazy">` : '<span>📦</span>';
      return `<a class="product" href="index.html?ad=${encodeURIComponent(ad.id)}"><div class="product-img">${picture}</div><div class="product-body"><h3 translate="no">${esc(ad.title || 'Elan')}</h3><p class="price">${Number(ad.price || 0).toLocaleString('az-AZ')} AZN${ad.category === 'Kirayə' ? (ad.description?.includes('\"period\":\"month\"') ? ' / ay' : ' / gün') : ''}</p><p>${esc(ad.location || 'Balakən')}</p></div></a>`;
    }).join('');
}
renderSeller();
  }
  loadSellerAds();
})();
