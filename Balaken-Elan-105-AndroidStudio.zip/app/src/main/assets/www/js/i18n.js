(() => {
 const rows=`Daxil ol / Qeydiyyat|Вход / Регистрация|Sign in / Register
＋ Elan yerləşdir|＋ Подать объявление|＋ Post an ad
Doğma Balakəndə|В родном Балакене|In your hometown Balakan
 axtardığın hər şey.| всё, что вы ищете.| everything you need.
Almaq da, satmaq da daha yaxındır. Şəhərdən kəndlərimizə qədər bir ünvanda.|Покупать и продавать стало ближе. Город и сёла — в одном месте.|Buy and sell closer to home. Our town and villages, all in one place.
✓ Yerli elanlar|✓ Местные объявления|✓ Local listings
✓ Sadə axtarış|✓ Простой поиск|✓ Easy search
✓ Birbaşa əlaqə|✓ Прямая связь|✓ Direct contact
ELAN AXTAR|ПОИСК ОБЪЯВЛЕНИЙ|FIND LISTINGS
Elan axtar|Поиск объявлений|Search listings
Elanın adı və ya açar söz|Название или ключевое слово|Title or keyword
Məsələn: telefon, ev, avtomobil…|Например: телефон, дом, автомобиль…|E.g. phone, house, car…
🔎 Elan axtar|🔎 Найти|🔎 Search
⚙️ Filtrlər|⚙️ Фильтры|⚙️ Filters
✖ Filtrləri bağla|✖ Закрыть фильтры|✖ Close filters
Filtrlər|Фильтры|Filters
↺ Filtrləri sıfırla|↺ Сбросить фильтры|↺ Reset filters
Şəhər, qəsəbə və ya kənd|Город, посёлок или село|Town or village
Bütün Balakən|Весь Балакен|All Balakan
Bütün Balakən ▾|Весь Балакен ▾|All Balakan ▾
Ərazi axtar|Поиск местности|Search area
Kənd axtar|Поиск села|Search village
Kateqoriya|Категория|Category
Bütün kateqoriyalar|Все категории|All categories
Hamısı|Все|All
Seçin|Выберите|Select
Kateqoriya seçin|Выберите категорию|Select category
Elektrik və ev əşyaları|Электротовары и бытовая техника|Appliances and household goods
Telefon və elektronika|Телефоны и электроника|Phones and electronics
Mebel|Мебель|Furniture
Avtomobil|Автомобили|Cars
Ev və torpaq|Дома и участки|Homes and land
Heyvanlar|Животные|Animals
Geyim və ayaqqabı|Одежда и обувь|Clothing and shoes
İş elanları|Работа|Jobs
Xidmətlər|Услуги|Services
Kirayə|Аренда|Rentals
Digər|Другое|Other
NƏ AXTARIRSAN?|ЧТО ВЫ ИЩЕТЕ?|WHAT ARE YOU LOOKING FOR?
Kateqoriyalara bax|Смотреть категории|Browse categories
ELAN LENTİ|ОБЪЯВЛЕНИЯ|LISTINGS
Balakəndə elanlar|Объявления в Балакене|Listings in Balakan
Elanlar yüklənir…|Загрузка объявлений…|Loading listings…
Bu axtarışa uyğun elan tapılmadı.|По вашему запросу ничего не найдено.|No listings match your search.
Əşyanın adı|Название предмета|Item name
Əşyanın adını yaz|Введите название|Enter item name
Heyvanın növü və ya adı|Вид или название животного|Animal type or name
Kirayə verilənin adı|Название объекта аренды|Rental item name
Marka|Марка|Make
Model|Модель|Model
Kirayə növü|Тип аренды|Rental type
Ev və mənzil|Дома и квартиры|Houses and apartments
Avadanlıq və alətlər|Оборудование и инструменты|Equipment and tools
Müddət|Срок|Period
Günlük|Посуточно|Daily
Aylıq|Помесячно|Monthly
Otaq sayı|Количество комнат|Rooms
Minimum qiymət|Минимальная цена|Minimum price
Maksimum qiymət|Максимальная цена|Maximum price
Sıralama|Сортировка|Sort by
Ən yeni elanlar|Сначала новые|Newest first
Əvvəl ucuz|Сначала дешевле|Price: low to high
Əvvəl baha|Сначала дороже|Price: high to low
🔍 Elanın adı, açıqlaması və telefonla axtarış|🔍 Поиск по названию, описанию и телефону|🔍 Search title, description and phone
‹ Geri|‹ Назад|‹ Previous
İrəli ›|Далее ›|Next ›
Səhifələr|Страницы|Pages
Hesabım|Мой аккаунт|My account
Ana səhifə|Главная|Home
Çıxış|Выйти|Sign out
Mənim elanlarım|Мои объявления|My listings
Yenilə|Обновить|Refresh
Kömək / Problem bildir|Помощь / Сообщить о проблеме|Help / Report a problem
Bizim rayon, bizim bazar|Наш район, наш рынок|Our district, our marketplace
Kənd bölgüsünün rəsmi mənbəyi|Официальный источник списка сёл|Official village list source
Bağla|Закрыть|Close
Qeydiyyat / Daxil ol|Регистрация / Вход|Register / Sign in
Google ilə qeydiyyat / giriş|Войти через Google|Continue with Google
E-poçtla qeydiyyat və giriş|Вход и регистрация по почте|Email sign-up and sign-in
Yeni hesab yarat|Создать аккаунт|Create an account
Hesabım var|У меня есть аккаунт|I have an account
İlk dəfə daxil olursansa, əvvəl yeni hesab yarat.|Если вы здесь впервые, создайте аккаунт.|First time here? Create an account.
İstifadəçi adı (qeydiyyat üçün)|Имя пользователя (для регистрации)|Username (for registration)
E-poçt|Электронная почта|Email
Şifrə|Пароль|Password
Ən azı 8 simvol|Не менее 8 символов|At least 8 characters
Şifrəni göstər|Показать пароль|Show password
Şifrəni gizlət|Скрыть пароль|Hide password
Hesab yarat|Создать аккаунт|Create account
Hesaba daxil ol|Войти|Sign in
Yeni şifrəni yadda saxla|Сохранить новый пароль|Save new password
Şifrəni unutmusunuz?|Забыли пароль?|Forgot password?
Təsdiq məktubunu yenidən göndər|Отправить письмо повторно|Resend confirmation email
Elan yerləşdir|Подать объявление|Post an ad
Elan dərhal yayımlanacaq. Dürüst məlumat və öz şəklindən istifadə et.|Объявление будет опубликовано сразу. Укажите достоверные сведения и свои фотографии.|Your listing will be published immediately. Use accurate information and your own photos.
Şəhər / qəsəbə / kənd ərazi dairəsi|Город / посёлок / сельский округ|Town / village area
Ərazi daxilində yeri dəqiqləşdir|Уточните местоположение|Specify location
Kirayə məlumatları|Данные аренды|Rental details
Nə kirayə verilir?|Что сдаётся в аренду?|What are you renting out?
Ödəniş müddəti|Период оплаты|Payment period
Buraxılış ili|Год выпуска|Year
Sürücü|Водитель|Driver
Sürücülü|С водителем|With driver
Sürücüsüz|Без водителя|Without driver
Evin növü|Тип жилья|Home type
Mənzil|Квартира|Apartment
Həyət evi|Частный дом|House
Bağ evi|Дача|Holiday home
Sahəsi (m²)|Площадь (м²)|Area (m²)
Əşyalar|Мебель|Furnishings
Əşyalı|С мебелью|Furnished
Əşyasız|Без мебели|Unfurnished
Avadanlığın növü|Тип оборудования|Equipment type
Elanın adı marka, model və ildən avtomatik hazırlanır.|Название создаётся из марки, модели и года.|The title is created from the make, model and year.
Rəng|Цвет|Colour
Ağ|Белый|White
Qara|Чёрный|Black
Boz|Серый|Grey
Gümüşü|Серебристый|Silver
Göy|Синий|Blue
Qırmızı|Красный|Red
Yaşıl|Зелёный|Green
Mühərrik həcmi (L)|Объём двигателя (л)|Engine size (L)
Mühərrik gücü (a.g.)|Мощность (л.с.)|Power (hp)
Yürüş (km)|Пробег (км)|Mileage (km)
Sürətlər qutusu|Коробка передач|Transmission
Mexaniki|Механическая|Manual
Avtomat|Автоматическая|Automatic
Robot|Робот|Automated manual
Variator|Вариатор|CVT
Elanın növü|Тип объявления|Listing type
İşçi axtarıram (vakansiya)|Ищу сотрудника (вакансия)|Hiring (vacancy)
İş axtarıram (namizəd)|Ищу работу (соискатель)|Looking for work
İş yeri / ünvan|Место работы / адрес|Workplace / address
İş qrafiki|График работы|Work schedule
Tam iş günü|Полный день|Full-time
Yarım iş günü|Неполный день|Part-time
Növbəli|Сменный|Shifts
Sərbəst qrafik|Гибкий график|Flexible
Uzaqdan|Удалённо|Remote
Razılaşma ilə|По договорённости|Negotiable
Təcrübə|Опыт|Experience
Tələb olunmur|Не требуется|Not required
1 ildən az|Менее года|Less than a year
1–3 il|1–3 года|1–3 years
3–5 il|3–5 лет|3–5 years
5 ildən çox|Более 5 лет|Over 5 years
Təhsil|Образование|Education
Fərqi yoxdur|Неважно|Any
Orta|Среднее|Secondary
Orta ixtisas|Среднее специальное|Vocational
Ali|Высшее|Higher education
İş tələbləri / bacarıqlar|Требования / навыки|Requirements / skills
Elanın adı|Название объявления|Listing title
Qiymət (AZN)|Цена (AZN)|Price (AZN)
Əlaqə telefonu|Контактный телефон|Contact phone
Elanın açıqlaması|Описание объявления|Listing description
Məhsulun vəziyyəti və digər məlumatlar|Состояние товара и другие сведения|Item condition and other details
Elan şəkilləri (istəyə bağlı)|Фотографии (необязательно)|Photos (optional)
Şəkilləri bura sürüşdür|Перетащите фотографии сюда|Drag photos here
və ya düyməyə basıb kompüterdən seç|или выберите файлы кнопкой|or use the button to choose files
Şəkilləri seç|Выбрать фотографии|Choose photos
Şəkil seçilməyib|Фотографии не выбраны|No photos selected
Elanı yayımla|Опубликовать|Publish listing
Elan məlumatları|Данные объявления|Listing details
Elan şəkilləri|Фотографии объявления|Listing photos
‹ Əvvəlki|‹ Предыдущая|‹ Previous
Növbəti ›|Следующая ›|Next ›
Ərazi:|Местность:|Area:
Kateqoriya:|Категория:|Category:
Elanın tarixi:|Дата объявления:|Posted:
Elanı yerləşdirən:|Автор:|Posted by:
Elanın təsviri|Описание|Description
Şikayət et|Пожаловаться|Report
Elan sahibinin bütün elanları|Все объявления продавца|All seller listings
Oxşar elanlar|Похожие объявления|Similar listings
Hazırda oxşar elan yoxdur.|Похожих объявлений пока нет.|No similar listings yet.
Telefon nömrəsi göstərilməyib.|Телефон не указан.|No phone number provided.
Şəkil əlavə edilməyib|Нет фотографии|No photo added
← Geri qayıt|← Назад|← Go back
Problemi göndər|Отправить|Send report
Müraciətlərim|Мои обращения|My reports
Problem nə ilə bağlıdır?|В чём проблема?|What is the problem?
Problemini izah et|Опишите проблему|Describe the problem
Şəkil yükləyə bilmirəm|Не могу загрузить фото|Cannot upload photos
Elan yerləşdirə bilmirəm|Не могу подать объявление|Cannot post a listing
Hesab / giriş problemi|Проблема со входом|Account / sign-in problem
Digər problem|Другая проблема|Other problem
Əlaqə telefonu və ya e-poçt (istəyə bağlı)|Телефон или почта (необязательно)|Phone or email (optional)
Ərazi dairəsinə aid yer|Место в округе|Place within the area
Ərazi dairəsinin kəndləri|Сёла округа|Villages in the area
Ərazini seçdikdən sonra alt seçimlər elə bunun altında açılacaq.|Выберите местность, чтобы увидеть дополнительные варианты ниже.|Choose an area to see its options below.
↳  Əvvəl ərazi seç. Alt seçimlər elə bunun altında görünəcək.|↳ Сначала выберите местность. Варианты появятся ниже.|↳ Choose an area first. Its options will appear below.
İş elanının növü|Тип объявления о работе|Job listing type
Bütün iş elanları|Все объявления о работе|All job listings
İşçi axtaranlar|Работодатели|Hiring
İş axtaranlar|Соискатели|Job seekers
İş elanları kateqoriyasını seçdikdə bu filtr görünür.|Этот фильтр доступен в категории «Работа».|This filter appears for the Jobs category.
Balakənə məxsus platforma|Платформа для Балакена|Balakan's local platform
· 1 şəhər, 1 qəsəbə və 57 kənd üzrə elanları axtar.|· Объявления из 1 города, 1 посёлка и 57 сёл.|· Search listings across 1 town, 1 settlement and 57 villages.
· Bizim rayon, bizim bazar|· Наш район, наш рынок|· Our district, our marketplace
Saytın idarə edilməsi|Управление сайтом|Site management
Sayta bax|Открыть сайт|View site
İstifadəçilər|Пользователи|Users
Elanlar|Объявления|Listings
Reklamlar|Реклама|Advertising
Şikayətlər|Жалобы|Reports
İstifadəçi problemləri|Проблемы пользователей|User support
Bu səhifədə istifadəçi axtar|Поиск пользователя на странице|Search users on this page
Əvvəlki|Назад|Previous
Növbəti|Далее|Next
Bütün elanlar|Все объявления|All listings
Elanın vəziyyəti|Статус объявления|Listing status
Aktiv|Активно|Active
Yoxlanılır|На проверке|Under review
Silinmiş / gizlədilmiş|Удалено / скрыто|Removed / hidden
Müddəti bitmiş|Срок истёк|Expired
Daha çox göstər|Показать ещё|Show more
Reklamın adı|Название рекламы|Advertisement title
Şəklin linki (HTTPS)|Ссылка на изображение (HTTPS)|Image URL (HTTPS)
Keçid linki (HTTPS)|Ссылка (HTTPS)|Destination URL (HTTPS)
Reklam əlavə et|Добавить рекламу|Add advertisement
Elan şikayətləri|Жалобы на объявления|Listing reports
İstifadəçilərin problemləri|Проблемы пользователей|User issues
Şəkil yüklənmir, elan yerləşmir və ya başqa çətinlik var? Nə baş verdiyini yaz.|Не загружается фото, не публикуется объявление или другая проблема? Опишите её.|Trouble uploading photos, posting a listing, or something else? Tell us what happened.
3–24 simvol; Azərbaycan və ingilis hərfləri, rəqəm və alt xətt (_) istifadə et. Bu, Gmail ünvanı deyil, saytda görünən addır.|3–24 символа: азербайджанские и английские буквы, цифры и знак _. Это имя на сайте, а не адрес Gmail.|3–24 characters: Azerbaijani or English letters, numbers and _. This is your display name, not your Gmail address.
Ərazi seçildikdən sonra alt hissə burada açılacaq.|После выбора местности здесь появятся варианты.|More options will appear here after you choose an area.
Seçilmiş ərazi dairəsinin kəndi|Село выбранного округа|Village in the selected area
Bir elana maksimum 10 şəkil. JPG, PNG və WEBP; hər şəkil 5 MB-dan kiçik olmalıdır. İlk şəkil elanın əsas şəkli olacaq. Şəkilləri sürüşdürərək sıralaya bilərsiniz.|До 10 фотографий. JPG, PNG или WEBP, менее 5 МБ каждая. Первое фото — главное. Перетаскивайте для изменения порядка.|Up to 10 photos. JPG, PNG or WEBP, each under 5 MB. The first photo is the cover. Drag photos to reorder.
Bloklanan hesab yeni elan yerləşdirə və mövcud elanlarını dəyişə bilməz. Mövcud elanlarını gizlətmək üçün Elanlar bölməsindən istifadə et.|Заблокированный пользователь не может создавать и менять объявления. Скрыть его объявления можно в разделе объявлений.|Blocked users cannot post or edit listings. Use Listings to hide their existing ads.
Elan axtarışı|Поиск объявлений|Listing search
İnzibati ərazi dairəsi|Административный округ|Administrative area
Hesab seçimi|Выбор аккаунта|Account options
Əşyanın adı və ya növü|Название или тип предмета|Item name or type
Heyvanın adı və ya növü|Название или вид животного|Animal name or type
Məsələn: Opel|Например: Opel|E.g. Opel
Məsələn: İşlənmiş soyuducu|Например: подержанный холодильник|E.g. used refrigerator
Məsələn: ad@gmail.com|Например: name@gmail.com|E.g. name@gmail.com
Məsələn: Balakenli_123|Например: Balakenli_123|E.g. Balakenli_123
Ad və ya e-poçt|Имя или почта|Name or email
Ad, telefon və ya ərazi|Название, телефон или местность|Title, phone or area
Hansı addımda problem yaranır? Xəta yazısı çıxırsa, bura yaz.|На каком шаге возникла проблема? Укажите текст ошибки.|At which step did it happen? Include any error message.
Səninlə əlaqə saxlamaq üçün|Для обратной связи|So we can contact you
Balakənin alqı-satqı məkanı|Торговая площадка Балакена|Balakan's marketplace
Elanları göstərmək üçün Supabase bağlantısı qurulmalıdır.|Для просмотра объявлений требуется подключение к Supabase.|A Supabase connection is required to load listings.
Hesabdan çıxıldı.|Вы вышли из аккаунта.|Signed out.
Əvvəlcə hesabına daxil ol.|Сначала войдите в аккаунт.|Sign in first.
Elan məlumatı tapılmadı. Səhifəni yenilə.|Объявление не найдено. Обновите страницу.|Listing not found. Refresh the page.
Elanı yadda saxla|Сохранить объявление|Save listing
Elanı redaktə et|Изменить объявление|Edit listing
Yadda saxla|Сохранить|Save
Ləğv et|Отмена|Cancel
Sil|Удалить|Delete
Göndərilir…|Отправка…|Sending…
Yüklənir…|Загрузка…|Loading…
Yeni şifrə|Новый пароль|New password`;
 const dict=Object.fromEntries(rows.split('\n').map(row=>{const [az,ru,en]=row.split('|');return [az.trim(),{ru,en}]}));
 let lang='az';try{lang=localStorage.getItem('balaken-language')||'az'}catch{}if(!['az','ru','en'].includes(lang))lang='az';
 const originals=new WeakMap();
 function translate(value){if(lang==='az')return value;const key=value.trim();let text=dict[key]?.[lang];
 if(!text){let m=key.match(/^(\d+) elan$/);if(m)text=lang==='ru'?`${m[1]} объявлений`:`${m[1]} listings`;}
 if(!text&&key.startsWith('☎ Telefon nömrəsi:'))text=key.replace('Telefon nömrəsi:',lang==='ru'?'Телефон:':'Phone:');
 if(!text&&key.endsWith(' *'))text=translate(key.slice(0,-2))+' *';
 if(!text&&key.includes(' · AZN')){const [label,unit]=key.split(' · AZN');text=translate(label)+' · AZN'+unit.replace('günlük/aylıq',lang==='ru'?'день/месяц':'day/month').replace('günlük',lang==='ru'?'день':'day').replace('aylıq',lang==='ru'?'месяц':'month')}
 return text?value.replace(key,text):value;
 }
 const excluded='script,style,textarea,[translate="no"],#siteLanguage,.ad-detail-description,.product h3,.related-ad strong,#galleryTitle,#accountInfo,#adminIdentity';
 function apply(){observer.disconnect();document.documentElement.lang=lang;
 // Freeze values before translating options: persisted category and location values stay Azerbaijani.
 document.querySelectorAll('option:not([value])').forEach(o=>o.setAttribute('value',o.textContent));
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let node;
 while(node=walker.nextNode()){if(node.parentElement.closest(excluded))continue;const previous=originals.get(node);const source=previous&&node.nodeValue===previous.rendered?previous.source:node.nodeValue;const rendered=translate(source);originals.set(node,{source,rendered});if(node.nodeValue!==rendered)node.nodeValue=rendered;}
 document.querySelectorAll('[placeholder],[aria-label],[title]').forEach(el=>{if(el.closest(excluded))return;let records=originals.get(el)||{};for(const attr of ['placeholder','aria-label','title']){if(!el.hasAttribute(attr))continue;const value=el.getAttribute(attr),old=records[attr],source=old&&old.rendered===value?old.source:value,rendered=translate(source);records[attr]={source,rendered};if(value!==rendered)el.setAttribute(attr,rendered)}originals.set(el,records)});
 observer.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['placeholder','aria-label','title']});
 }
 const observer=new MutationObserver(apply);
 const select=document.getElementById('siteLanguage');select.value=lang;select.addEventListener('change',()=>{lang=select.value;try{localStorage.setItem('balaken-language',lang)}catch{}apply()});apply();
})();
